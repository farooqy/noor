<?php 
if(isset($_POST['invoice_desc']) && isset($_POST['invoice_to']))
{
	//print_r($_POST);
	$inv_to = $_POST["invoice_to"];
	$POST_DESC = $_POST["invoice_desc"];
	$POST_PRICE = $_POST["invoice_price"];
	$POST_QUAN = $_POST["invoice_quantity"];
	if(count($POST_QUAN) !== count($POST_PRICE) || count($POST_DESC) != count($POST_PRICE))
	{
		echo json_encode(array(
			false,
			"The description and the item price or quantity are not in correct order"));
		exit(0);
	}
	else if(count($POST_PRICE) <=0)
	{
		echo json_encode(array(
			false,
			"The item details should be filled "));
		exit(0);
	}
	else
	{
		$items = array();
		$num_items = count($POST_PRICE);
		for($i=0; $i<$num_items; $i++)
		{
			if($POST_PRICE[$i] < 0)
			{
				echo json_encode(array(
					false,
					"The price of the ".($i+1)." item is less than zero",
					));
				exit(0);
			}
			else if($POST_QUAN[$i] <= 0)
			{
				echo json_encode(array(
					false,
					"The quantity of the ".($i+1)." item should be more than zero(0)"
					));
				exit(0);
			}
			else if(empty($POST_DESC[$i]))
			{
				echo json_encode(array(
					false,
					"Please fill the description of the item ".($i+1)
					));
				exit(0);
			}
			else
			{
				$x = array(
					"price" => $POST_PRICE[$i],
					"quantity" => $POST_QUAN[$i],
					"desc" => $POST_DESC[$i]);
				array_push($items, $x);
			}
		}
		require_once("classes/invoice.php");
		$Invoice = new Invoice();
		$details = array(
			"holder" => $inv_to,
			"items" => $items);
		$Invoice->Set_Inv_Details($details);
		$is_saved = $Invoice->Save_Invoice();
		if($is_saved)
		{
			echo json_encode(array(
				true,
				"success"
				));
		}
		else
		{
			$error = $Invoice->Get_Message();
			echo json_encode(array(
				false,
				"FAILED TO SAVE: ".$error));
			exit(0);
		}

	}
}
else
{
	echo json_encode(array(
		false,
		'You have to feed the beast that you seek'
		));
}
?>