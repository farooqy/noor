/* $ */
var site_url = 'http://localhost/sites/alnezam/';
//alert('doc is not ready');
$(document).ready(function() {
	//alert('what is happeining');
	//prevent default trigger
	$('.preventDefault').click(function(e){
		e.preventDefault()
	});
	//display the file upload
	$('.displayTrigger').click(function(e){
		e.preventDefault();
		var target = $(this).attr('target');
		var current  = $('.current_view');
		$(current).removeClass('.current_view');
		$(current).hide();
		Reset_Object('.loader-text', 'text');
		Reset_Object('.loader-error', 'text');
		$('.'+target).toggle();
		$('.'+target).addClass('current_view');
	});

	//close any pop up open
	$('.close_pop').click(function(){
		var target = $(this).attr('target');
		$('.'+target).toggle();
	});

	//trigger the upload button for files
	$('.upload_trigger').click(function(){
		var target = $(this).attr('target');
		$('.'+target).click();
	});

	//process the file to be uploaded
	$('.upload_file').change(function(){
		var all_files = $(this).prop('files');
		//$('.actual_file:file').val(all_files);
		//all_files = $('.actual_file').prop('files');
		var file_form = document.getElementsByClassName('file_form')[0];
		var form_data = new FormData(file_form)
		form_data.append('type', 'file_type')
		var ajax_status = jquery_upload(form_data, "file_handle.php",
			'loader','showApproved');

	});
	//process the folder to be created
	$('.folder_form').submit(function(e){
		e.preventDefault();
		var form_data = new FormData(this);
		var ajax_status = jquery_upload(form_data, 
			'folder_handle.php','loader','folderInfo'
			)
	});

	//cancel uploads
	$('.cancel_upload').click(function(){
		var form_data = new FormData();
		form_data.append('type', 'reset');
		var ajax_status = jquery_upload(form_data, "reset.php");
		setTimeout(function(){
			$('.loader-text').text('DONE RESETTING');
			$('.loader-error').text('');
			$('.appendfiles').html('');
		}, 1000);
			
	});
	//inventory submit
	$('.inventory-form').submit(function(e){
	
		e.preventDefault();
		var form_data = new FormData(this);
		var ajax_status = jquery_upload(form_data, 
			"inventory_handle.php", "loader", "inventory");
	});

	$('.new_acc_form').submit(function(e){
		e.preventDefault();
		var form_data = new FormData(this);
		var tar_url = "new_acc_handle.php";
		var ajax_status = jquery_upload(form_data, tar_url, 'loader',
			'new_acc');
	});

	$('.locked-icon').click(function () {
		alert('This folder is locked and can only be viewed '+
			'by the administrator or the manager');
	});

	$('.cash_type').change(function(){
		var val = $(this).val();
		if(val === 'cheque')
		{
			$('.cheq_num').css('display','block');
		}
		else
		{
			$('.cheq_num').css('display','none');
		}
	});

	$('.dcash_form').submit(function(e){
		e.preventDefault();
		var form_data = new FormData(this);
		var target_url = 'dcash_handle.php';
		var ajax_status = jquery_upload(form_data, target_url,
			'loader','dcash');
	});
	$('.invoice-form').submit(function(e){
		e.preventDefault();
		var form_data = new FormData(this);
		var target_url = 'invoice_handle.php';
		var ajax_status = jquery_upload(form_data,target_url,'loader','invoice');
	});

	$('.add-invoice').click(function(){
		var date = new Date();
		var token = date.getTime();
		var quan = '<input type=\'number\' class=\'input-text col-md-5 col-lg-5\''+
		'name=\'invoice_quantity[]\' required placeholder=\'Quantity\'>';
		var price = '<input type=\'number\' class=\'input-text col-md-5 col-lg-5\''+
		'name=\'invoice_price[]\' required placeholder=\'Price\'>';
		var div = '<div class=\'row apphendinvoice mar-t-10 '+
		token+'\'>';
		var desc = div+'<input type=\'text\' name=\'invoice_desc[]\''+
		'class=\'input-text col-md-11 col-lg-11\' placeholder=\'Enter the description\' ><div class=\'col-md-1 col-lg-1'+token+' cancel_icon\' onclick=\'Remove_Me(this)\' target=\''+token+'\'>X</div></div>';
		div = desc+div+quan+'<div class=\'col-md-2 col-lg2\'></div> '+price+'</div>';
		$('.apphendinvoice'). last().after(div);

	});
});

function jquery_upload(data_to_send, target_url, loader='loader',
	extra='None')
{
	var loader_text = $('.'+loader).children('.loader-text');
	var loader_error =$('.'+loader).children('.loader-error');
	$(loader_text).text('Loading...');
	$(loader_error).text('');
	$.ajax({
    xhr: function() {
        var xhr = new window.XMLHttpRequest();

        // Upload progress
        xhr.upload.addEventListener("progress", function(evt){
            if (evt.lengthComputable) {
                var percentComplete = Math.round((evt.loaded / evt.total)*100);
                //Do something with upload progress
                $(loader_text).text('Loading: '+percentComplete+"%");
            }
       }, false);

       // Download progress
       xhr.addEventListener("progress", function(evt){
           if (evt.lengthComputable) {
               var percentComplete = Math.round((evt.loaded / evt.total)*100);
               // Do something with download progress
               $(loader_text).text('Processing: '+percentComplete+"%");
             if(percentComplete >= 100)
               {
                 $(loader_text).text('Completed: '+percentComplete+"%");
               }
           }
       }, false);

       return xhr;
    },
    type:"POST",
    url:target_url,
    data: data_to_send,
    contentType: false,
    processData: false,
    cache:false,
    success:function(data){
      data = JSON.parse(data);
      if(data[0] === true && data[1] === "success")
      {
      	//alert("success");
      	/*if(!data[2])
      	{
      		$(loader_text).text('success');
      		return true;
      	}*/
      	if(extra == 'showApproved' && data[2])
      	{
	      	var _files = data[2];
	      	var imgsrc = site_url+'icons/Approve_icon.svg';
	      	var img = "<img src='"+imgsrc+"' height='25px' />";
      		for(var i=0; i<_files.length; i++)
	      	{
	      		var file_src = "<div > "+(i+1)+' '+_files[i]['name'];
	      		file_src += img+"</div>";
	      		$('.appendfiles').append(file_src);
	      	}
	    }
	    else if(extra == "inventory")
	    {
	    	//alert("will reload to "+site_url+'?display=inventory');

	    	window.location.assign(site_url+'?display=inventory');
	    }
	    else if(extra == 'new_acc')
	    {

	    	window.location.assign(site_url+'?display=accounts');
	    }
	    else if(extra === "dcash")
	    {
	    	window.location.assign(site_url+"?display=dcash");
	    }
	    else
	    {
	    	$('.loader_text').text('success');
	    }
	    setTimeout(function() {
      		$(loader_text).text('Successfully uploaded');
      	}, 1000);
      	
        return true;
      }
      else if(data[0] === false)
        {
        	//alert("failed: "+JSON.stringify(data[1]))
        	$(loader_text).text("ERROR");
        	$(loader_error).text(data[1])
        	return false
        }
    },
    error:function(error){
      error = JSON.stringify(error);
      $(loader_text).text('Connection error: '+error);
      return false;
    }
    
    
  });
}
function Reset_Object(selector, object='text')
{
	if(object === 'text')
	{
		$(selector).text('');
	}
	else
	{
		$(selector).html('');
	}
}
function Remove_Me(target)
{
	var target = $(target).attr('target');
	$('.'+target).remove();
}