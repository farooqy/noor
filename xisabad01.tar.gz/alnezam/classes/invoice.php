<?php 

require_once("database.php");
require_once("query_handle.php");
require_once("logger.php");
class Invoice {
	//folder attributes
	protected $inv_id = null;
	protected $inv_no = null;
	protected $inv_holder = null;
	protected $inv_items = array();
	protected $inv_date = null;
	protected $inv_token = null;
	protected $SERIAL_CODE = "XYZ";
	//object attributes
	protected $is_isset = false;

	//error attributes
	protected $error_status = False; 
	protected $error_message = "No Folder Error";
	protected $error_file = "Invoice_errors";
	protected $Logger = null;
	private $FOLDER_EXIST_ERROR = "The folder you are creating already exist.";
	private $PERMISSIN_DENIED_ERROR = "You do not have permission to 
	create a folder in this directory";
	private $SQL_ERROR = "The query to process your request contains an 
	error, please contact administrator";
	private $DETAILS_NOT_SET_ERROR = "The folder details are not set";
	private $EXIST_FAILED_ERROR = "Failed to check the existence of the user ";

	//db connection attributes
	protected $conn = ""; //hold the db query arrow 
	protected $db = "";//holds the database object
	protected $db_status = false; //not conencted initially
	private $Query_Handle = null;

	public function __construct()
  	{

  		$this->error_file = "Invoice.error";
  		$this->Logger = new Logger($this->error_file);
    	$this->db = new connection();
	    $status = $this->db->connection_status();
	    if($status)
	    {
	      $this->conn = $this->db->connection();
	      $this->db_status = true; //db connection success
	      $this->Query_Handle =new Query_Handle($this->db->connection());
	    }
	    else
	    {
	      $this->error_status = true;
	      $this->error_message = "Connection failed";
	    }
  	}
	public function Db_Status()
	{
		return $this->db_status;
	}
	  
	public function Get_Message()
	{
		return $this->error_message;
	}
	public function Set_Error($error)
	{
		$this->error_status = true;
		$this->error_message = $error;
	}
	public function Log_Error($error)
	{
		if($this->Logger->Initial_Error() === true)
		{
			$error = $this->error_message." Logging Intial failed: 
			".$this->Logger->Failed_Message()." MAIN ERROR: ".$error;
			$this->Set_Error($error);
		}
		else
		{
			$is_logged = $this->Logger->Write_Error($error);
			if($is_logged === false)
			{
				$error = $this->error_message." Logging failed: 
				".$this->Logger->Failed_Message()." MAIN ERROR: ".$error;
				$this->Set_Error($error);
			}
		}
	}
	public function Set_Inv_Details($details)
	{
		$this->inv_no = $this->New_Inv_Num();
		$this->inv_holder = $details["holder"];
		$this->inv_items = $details["items"];
		$this->inv_date = time();
		$this->inv_token = hash('md5',$this->inv_date, false);

		$this->is_isset = true;
	}
	public function Save_Invoice()
	{
		if($this->is_isset === false)
		{
			$this->Set_Error($this->DETAILS_NOT_SET_ERROR);
			return false;
		}
		else
		{
			$num_items = count($this->inv_items);
			$query = "INSERT INTO `invoices` (inv_no, inv_holder, inv_date, inv_token, inv_item_price, inv_item_quan, inv_item_desc) VALUES('$this->inv_no',  '$this->inv_holder', $this->inv_date, '$this->inv_token',";
			for($i=0; $i<$num_items; $i++)
			{
				$item_desc = $this->inv_items[$i]["desc"];
				$item_price = $this->inv_items[$i]["price"];
				$item_quan = $this->inv_items[$i]["quantity"];

				$inv_query = $query.$item_price.','.$item_quan.','."'$item_desc')";

				$is_saved = $this->Query_Handle->Make_Query($inv_query);
				if($is_saved)
					continue;
				else
				{
					$error = $this->Query_Handle->Query_Message();
					$this->Set_Error($this->SQL_ERROR);
					$this->Log_Error($error);
					return false;
				}

			}
			return true;
		}
	}protected function New_Inv_Num()
  	{
      $serial_q = "SELECT inv_id FROM `invoices` WHERE 1";
      $existing_serial = $this->Query_Handle->Make_Query($serial_q, "fetch");
      if($existing_serial === false)
      {
        $this->Set_Error($this->SERIAL_QUERRY_ERROR);
        $this->Log_Error($this->Query_Handle->Query_Message());
        return false;
      }
      else if(!is_array($existing_serial))
      {
        $error = "RETURNED NON ARRAY INVOICE NUMBER QUERRY";
        $this->Set_Error($error." VALUE: ".$existing_serial);
        $this->Log_Error($this->Query_Handle->Query_Message());
        return false;
      }
      else
      {
    		$num_inventories = count($existing_serial);
    		//$code = "0";
    		$code = $this->Calculate_Inventory_Num($num_inventories);
    		
    		$serial_code = $this->SERIAL_CODE.$code;
        if(in_array($serial_code, array_column($existing_serial, "inv_id")))
        {
          $this->Set_Error($this->SERIAL_COLLISION);
          //$this->Log_Error($this->Query_Handle->Query_Message());
          return false;
        }
        else
      		return $serial_code;
      }

  	}
  	public function Change_Serial_Code($new_code)
  	{
  		$this->SERIAL_CODE = $new_code;
  	}
  	public function Calculate_Inventory_Num($num_inventories)
  	{

  		if($num_inventories < 10)
  		{
  			$code = "000000".$num_inventories;
  		}
  		else if($num_inventories <100 && $num_inventories > 9)
  		{
  			$code = "00000".$num_inventories;
  		}
  		else if($num_inventories < 1000 && $num_inventories > 99)
  		{
  			$code = "0000".$num_inventories;
  		}
  		else if($num_inventories < 10000 && $num_inventories > 999)
  		{
  			$code = "000".$num_inventories;
  		}
  		else if($num_inventories < 100000 && $num_inventories > 9999)
  		{
  			$code = "00".$num_inventories;
  		}
  		else if($num_inventories < 1000000 && $num_inventories > 99999)
  		{
  			$code = "0".$num_inventories;
  		}
  		else 
  		{
  			$code = $num_inventories;
  		}
  		return $code;
  	}

  	public function Get_Invoices()
  	{
  		$query = "SELECT DISTINCT inv_no, inv_holder, inv_date, inv_token FROM invoices WHERE 1 ORDER BY inv_date DESC";

  		$invoices = $this->Query_Handle->Make_Query($query, "fetch");
  		if($invoices === false)
  		{
  		 	$error = $this->Query_Handle->Query_Message();
  			$this->Set_Error($this->SQL_ERROR);
  			$this->Log_Error($error);
  			return false;
  		}
  		else
  			return $invoices;
  	}
  	public function Get_Given_Inv($inv_num, $inv_token)
  	{
  		$query = "SELECT * FROM `invoices`
  		 WHERE inv_no = '$inv_num' AND inv_token = '$inv_token'";

  		 $inv_req = $this->Query_Handle->Make_Query($query, "fetch");
  		 if($inv_req === false)
  		 {
  		 	$error = $this->Query_Handle->Query_Message();
  		 	$this->Set_Error($this->SQL_ERROR);
  		 	$this->Log_Error($error);
  		 	return false;
  		 }
  		 else
  		 	return $inv_req;
  	}

}
?>