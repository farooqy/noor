<?php 

require_once("database.php");
require_once("query_handle.php");
require_once("logger.php");
class Folder {
	//folder attributes
	protected $folder_id = null;
	protected $folder_name = null;
	protected $folder_parent = null;
	protected $folder_status = null;
	protected $folder_visible = null;

	//object attributes
	protected $is_isset = false;

	//error attributes
	protected $error_status = False; 
	protected $error_message = "No Folder Error";
	protected $error_file = "folder_errors";
	protected $Logger = null;
	private $FOLDER_EXIST_ERROR = "The folder you are creating already exist.";
	private $PERMISSIN_DENIED_ERROR = "You do not have permission to 
	create a folder in this directory";
	private $SQL_ERROR = "The query to process your request contains an 
	error, please contact administrator";
	private $DETAILS_NOT_SET_ERROR = "The folder details are not set";
	private $EXIST_FAILED_ERROR = "Failed to check the existence of the user ";

	//db connection attributes
	protected $conn = ""; //hold the db query arrow 
	protected $db = "";//holds the database object
	protected $db_status = false; //not conencted initially
	private $Query_Handle = null;

	public function __construct()
  	{

  		$this->error_file = "folders.error";
  		$this->Logger = new Logger($this->error_file);
    	$this->db = new connection();
	    $status = $this->db->connection_status();
	    if($status)
	    {
	      $this->conn = $this->db->connection();
	      $this->db_status = true; //db connection success
	      $this->Query_Handle =new Query_Handle($this->db->connection());
	    }
	    else
	    {
	      $this->error_status = true;
	      $this->error_message = "Connection failed";
	    }
  	}
	public function Db_Status()
	{
		return $this->db_status;
	}
	  
	public function Get_Message()
	{
		return $this->error_message;
	}
	public function Set_Error($error)
	{
		$this->error_status = true;
		$this->error_message = $error;
	}
	public function Log_Error($error)
	{
		if($this->Logger->Initial_Error() === true)
		{
			$error = $this->error_message." Logging Intial failed: 
			".$this->Logger->Failed_Message()." MAIN ERROR: ".$error;
			$this->Set_Error($error);
		}
		else
		{
			$is_logged = $this->Logger->Write_Error($error);
			if($is_logged === false)
			{
				$error = $this->error_message." Logging failed: 
				".$this->Logger->Failed_Message()." MAIN ERROR: ".$error;
				$this->Set_Error($error);
			}
		}
	}
	public function Set_Folder_Details($details)
	{
		$this->folder_name = $details["name"];
		$this->folder_parent = $details["parent"];
		$this->folder_status = "active";
		$this->folder_visible = $details["visible"];

		$this->is_isset = true;
	}
	public function Save_Folder()
	{
		if($this->is_isset === false)
		{
			$this->error_status = true;
			$this->error_message = $this->DETAILS_NOT_SET_ERROR;
			return false;
		}
		else
		{
			$is_exist = $this->Check_Folder_Exist();
			if($is_exist === false)
			{
				$query = "INSERT INTO `folders` 
				(folder_name, folder_parent, folder_status, folder_visible) 
				VALUES('$this->folder_name', '$this->folder_parent', 
				'$this->folder_status', '$this->folder_visible')";
				$is_saved = $this->Query_Handle->Make_Query($query);
				//echo "use is new";
				if($is_saved)
				{
					//echo "user is saved";
					return true;
				}
				else
				{
					$error = $this->Query_Handle->Query_Message();
					$this->Set_Error($this->SQL_ERROR);
					$this->Log_Error($error);
					return false;
				}
			}
			else if($is_exist === "error")
			{
				return false;
			}
			else
			{
				return false;
			}
		}
	}
	protected function Check_Folder_Exist()
	{
		$query = "SELECT * FROM `folders` 
		WHERE folder_name = '$this->folder_name' 
		AND folder_parent = '$this->folder_parent'";
		$is_exist = $this->Query_Handle->Make_Query($query, "fetch");
		if($is_exist === false || !is_array($is_exist))
		{
			$error = $EXIST_FAILED_ERROR;
			$this->Set_Error($error);
			return "error";
		}
		else if(count($is_exist) >= 1)
		{
			$this->Set_Error($this->FOLDER_EXIST_ERROR);
			return true;
		}
		else
		{
			return false;
		}

	}

	public function Get_Dir_Folders($dir)
	{
		$query = "SELECT * FROM `folders` 
		WHERE folder_parent = '$dir' AND folder_status = 'active'";
		$list = $this->Query_Handle->Make_Query($query, "fetch");
		return $list;
	}
	public function Get_Given_Folder($dir_id)
	{
		$query = "SELECT * FROM `folders` 
		WHERE folder_id = $dir_id AND folder_status = 'active'";
		$folder= $this->Query_Handle->Make_Query($query, "fetch");
		if($folder === false)
		{
			$error = $this->Query_Handle->Get_Message();
			$this->Set_Error($this->SQL_ERROR);
			$this->Log_Error($error);
			return false;
		}
		else
			return $folder;
	}
}
?>