-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: alnezamDB
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `acc_id` bigint(22) NOT NULL AUTO_INCREMENT,
  `acc_name` varchar(255) NOT NULL,
  `acc_desc` varchar(1000) NOT NULL,
  `acc_type` varchar(20) NOT NULL,
  `acc_token` varchar(255) NOT NULL,
  `acc_date` bigint(22) NOT NULL,
  `acc_status` varchar(20) NOT NULL,
  `acc_folder` int(11) NOT NULL,
  PRIMARY KEY (`acc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'Test account','This is the description of the test account','standard','ee524bf96fbf146849599f7db9e129e7',1514392497,'active',0),(2,'Test extinct ','This is the description of the account. This account does not affect the other accounts. It is just to prove some calculations','extinct','6a0d79d5ffa50df465e5f43b72af8e39',1514782627,'active',0),(3,'Cash Account','This is the cash account of the company, all cash flows must be seen in this account.','standard','d05594c71608d80308b90f7e809c041e',1515603076,'active',0),(4,'Noor Bank','This is a bank account','standard','fad93c53120410906d8d14bb9d7271fe',1515691442,'active',0),(5,'Suleiman Account','This is a personal account.','standard','e73fe334f1b6bf51515017cd9e1057ec',1515692201,'active',0);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dcash`
--

DROP TABLE IF EXISTS `dcash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dcash` (
  `cash_id` bigint(22) NOT NULL AUTO_INCREMENT,
  `cash_date` bigint(22) NOT NULL,
  `cash_desc` varchar(1000) NOT NULL,
  `cash_type` varchar(10) NOT NULL,
  `cash_cheq_no` int(11) NOT NULL,
  `cash_amount` float NOT NULL,
  `cash_status` varchar(10) NOT NULL,
  `cash_token` varchar(255) NOT NULL,
  `cash_trans_from` int(11) NOT NULL,
  `cash_trans_to` int(11) NOT NULL,
  PRIMARY KEY (`cash_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dcash`
--

LOCK TABLES `dcash` WRITE;
/*!40000 ALTER TABLE `dcash` DISABLE KEYS */;
INSERT INTO `dcash` VALUES (19,1515677503,'Transfers to the cash account','cash',0,5000,'active','6403abbba74a5bf831efbc5a88dc4a47',1,3),(20,1515691610,'Transfer money from the cash account to Noor bank','cash',0,2500,'active','54f3e4176a10225467da3e965a208b34',3,4),(21,1515692691,'Lend suleiman some money','cheque',100232,1000,'active','c85ee7231300782267f78d2e425b45ee',4,5),(22,1515838205,'Suleiman pays back some of his debt his debt','cash',0,300,'active','85dc242ea4cb5616d1ed5168594d43ef',5,3);
/*!40000 ALTER TABLE `dcash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folders`
--

DROP TABLE IF EXISTS `folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folders` (
  `folder_id` int(11) NOT NULL AUTO_INCREMENT,
  `folder_name` varchar(255) NOT NULL,
  `folder_parent` int(11) DEFAULT NULL,
  `folder_status` varchar(20) NOT NULL,
  `folder_visible` varchar(20) NOT NULL,
  PRIMARY KEY (`folder_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders`
--

LOCK TABLES `folders` WRITE;
/*!40000 ALTER TABLE `folders` DISABLE KEYS */;
INSERT INTO `folders` VALUES (1,'Test folder',0,'active','all'),(2,'Test folder two',0,'active','all'),(3,'Admin folder',0,'active','admin');
/*!40000 ALTER TABLE `folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `item_id` bigint(22) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(255) NOT NULL,
  `item_desc` varchar(1000) NOT NULL,
  `item_quantity` float DEFAULT NULL,
  `item_price` float DEFAULT NULL,
  `item_date` int(22) NOT NULL,
  `item_token` varchar(255) NOT NULL,
  `serial_no` varchar(20) NOT NULL,
  `close_date` int(22) DEFAULT NULL,
  `close_amount` int(22) DEFAULT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'Item one','This is the description of item one',1,0,1514026671,'ec9a2a96d0c2fc38eb7a1e9fe53eaa0c','XYZ0000001',NULL,NULL),(2,'Item two','This is the description of the second item',6,3,1514027578,'907e5f50087f9c3f6a98a4c0817b9345','XYZ0000001',NULL,NULL),(3,'Item Three','Description three',20,15,1514027733,'2c13cc97b30031e42baa52321490e525','XYZ0000001',NULL,NULL),(4,'item four','description four',40,4,1514027829,'1c8bcd9d6b18b7981d27493617811716','XYZ0000001',NULL,NULL),(5,'item five','Description five',51,8,1514028080,'e8990b14750fd5a63507aed6965354f5','XYZ0000001',NULL,NULL),(6,'Item six','This is the description for item six',3,75,1514779222,'98167c74f403709fa6641df67dce57f2','XYZ0000001',NULL,NULL),(7,'Item seven','This is the description for item seven',11,65,1514779429,'83fd6bf972b2688a80e1e535ffce0e78','XYZ000000S',NULL,NULL),(8,'Item seven','This is the description for item seven',11,65,1514779444,'75c5e110eb7ef86a1937764d66931c8d','XYZ000000S',NULL,NULL),(9,'Item seven','This is the description for item seven',11,65,1514779494,'524a739a3019dd698b167d6be1afb0de','XYZ000000S',NULL,NULL),(10,'Item seven','This is the description for item seven',11,65,1514779536,'2aca1abea773d77095793ebf68872399','XYZ0000009',NULL,NULL),(11,'Item eight','This is the description for item eight',35,53,1514781990,'a5a71d3730169b04454949d213fc7336','XYZ0000010',NULL,NULL);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `inv_id` bigint(22) NOT NULL AUTO_INCREMENT,
  `inv_no` varchar(20) NOT NULL,
  `inv_holder` varchar(200) NOT NULL,
  `inv_item_desc` varchar(500) NOT NULL,
  `inv_item_price` float NOT NULL,
  `inv_item_quan` float NOT NULL,
  `inv_date` bigint(22) NOT NULL,
  `inv_token` varchar(255) NOT NULL,
  PRIMARY KEY (`inv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (1,'XYZ0000000','perosn one','item one',12,8,1516510220,'fa79a4d727de8d5ada055d55879f7ca1'),(2,'XYZ0000001','Second person','item one',13,9,1516512997,'788d89fcb9124ee7cc0f8031ca4040bb'),(3,'XYZ0000002','Third person','Item one description',20,4,1516679394,'c40a176165d43d522be3a76ca6920efa'),(4,'XYZ0000003','Fourth person','Item one description',20,4,1516679548,'34620ace0125a851f76265e54c5fe137'),(5,'XYZ0000003','Fourth person','Item two description',35,8,1516679548,'34620ace0125a851f76265e54c5fe137');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ledger`
--

DROP TABLE IF EXISTS `ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ledger` (
  `ldg_id` bigint(22) NOT NULL AUTO_INCREMENT,
  `ldg_dcash_id` bigint(22) NOT NULL,
  `ldg_type` varchar(10) NOT NULL,
  `ldg_amount` float NOT NULL,
  `ldg_status` varchar(20) NOT NULL,
  `ldg_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ldg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ledger`
--

LOCK TABLES `ledger` WRITE;
/*!40000 ALTER TABLE `ledger` DISABLE KEYS */;
INSERT INTO `ledger` VALUES (1,19,'debit',5000,'active','6403abbba74a5bf831efbc5a88dc4a47'),(2,19,'credit',5000,'active','6403abbba74a5bf831efbc5a88dc4a47'),(3,20,'debit',2500,'active','54f3e4176a10225467da3e965a208b34'),(4,20,'credit',2500,'active','54f3e4176a10225467da3e965a208b34'),(5,21,'debit',1000,'active','c85ee7231300782267f78d2e425b45ee'),(6,21,'credit',1000,'active','c85ee7231300782267f78d2e425b45ee'),(7,22,'debit',300,'active','85dc242ea4cb5616d1ed5168594d43ef'),(8,22,'credit',300,'active','85dc242ea4cb5616d1ed5168594d43ef');
/*!40000 ALTER TABLE `ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `tran_id` bigint(22) NOT NULL AUTO_INCREMENT,
  `acc_id` int(11) NOT NULL,
  `tran_desc` varchar(1000) NOT NULL,
  `tran_discount` float DEFAULT NULL,
  `tran_debit` float DEFAULT NULL,
  `tran_credit` float DEFAULT NULL,
  `tran_date` bigint(22) NOT NULL,
  `tran_token` varchar(300) NOT NULL,
  `tran_status` varchar(20) NOT NULL,
  PRIMARY KEY (`tran_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-22 21:04:54
