<?php
require_once("database.php");
require_once("logger.php");
require_once("query_handle.php");

class Inventory{

	protected $item_id = null;
	protected $serial_no = null;
	protected $item_name = null;
	protected $item_desc = null;
	protected $item_quan = null;
	protected $item_price = null;
	protected $item_date = null;
	protected $item_token = null;
	protected $close_date = null;
	protected $close_amount = null;
	protected $SERIAL_CODE = null;

	protected $is_isset = false;

	//db connection attributes
	protected $conn = ""; //hold the db query arrow 
	protected $db = "";//holds the database object
	protected $db_status = false; //not conencted initially
	private $Query_Handle = null;


	protected $error_status = False; 
	protected $error_message = "No Folder Error";
	protected $error_file = null;
	protected $Logger = null;

	private $UNSET_ERROR = "The details of the Inventory is not set, 
	unable to save it";
	private $SERIAL_COLLISION = "The serial number given to the inventory has a collision with another item";
	private $SQL_ERROR = "The query to process your request contains an 
	error, please contact administrator";
  private $SERIAL_QUERRY_ERROR = "The query to fetch the serial numbers could not be processed. Please contact admin";

	public function __construct()
  	{
  		$this->SERIAL_CODE = "XYZ";
  		$this->error_file = "inventory.error";
  		$this->Logger = new Logger($this->error_file);
    	$this->db = new connection();
	    $status = $this->db->connection_status();
	    if($status)
	    {
	      $this->conn = $this->db->connection();
	      $this->db_status = true; //db connection success
	      $this->Query_Handle =new Query_Handle($this->db->connection());
	    }
	    else
	    {
	      $this->error_status = true;
	      $this->error_message = "Connection failed";
	    }
  	}

	public function Db_Status()
	{
		return $this->db_status;
	}
	  
	public function Get_Message()
	{
		return $this->error_message;
	}
	public function Set_Error($error)
	{
		$this->error_status = true;
		$this->error_message = $error;
	}
	public function Log_Error($error)
	{
		if($this->Logger->Initial_Error() === true)
		{
			$error = $this->error_message." Logging Initial failed: 
			".$this->Logger->Failed_Message()." MAIN ERROR: ".$error;
			$this->Set_Error($error);
		}
		else
		{
			$is_logged = $this->Logger->Write_Error($error);
			if($is_logged === false)
			{
				$error = $this->error_message." Logging failed: 
				".$this->Logger->Failed_Message()." MAIN ERROR: ".$error;
				$this->Set_Error($error);
			}
		}
	}

  	public function Set_Details($details)
  	{
  		$this->item_name = $details["item_name"];
  		$this->item_desc = $details["item_desc"];
  		$this->item_quan = $details["item_quan"];
  		$this->item_price = $details["item_price"];
  		$this->item_date = time();
  		$this->item_token = hash('md5', $this->item_date, false);
  		$this->serial_no = $this->New_Serial_No();
      if($this->serial_no === false)
        return false;

  		$this->is_isset = true;
  	}

  	public function Save_Inventory()
  	{
  		if($this->is_isset === false)
  		{
  			$this->Set_Error($UNSET_ERROR);
  			return false;
  		}
  		$query = "INSERT INTO `inventory` 
  		(serial_no, item_name, item_desc, item_quantity, item_price,
  		item_date, item_token) VALUES(
  		'$this->serial_no', '$this->item_name', '$this->item_desc',
  		$this->item_quan, $this->item_price,
  		 $this->item_date, '$this->item_token')";

  		 $is_saved = $this->Query_Handle->Make_Query($query);
  		 if($is_saved)
  		 {
  		 	return true;
  		 	//echo json_encode(array(true, "success"));
  		 }
  		 else
  		 {
  		 	$error = $this->Query_Handle->Query_Message();
  		 	$this->Set_Error($this->SQL_ERROR);
  		 	$this->Log_Error($error);
  		 	return false;
  		 }
  	}

  	protected function New_Serial_No()
  	{
      $serial_q = "SELECT serial_no FROM `inventory` WHERE 1";
      $existing_serial = $this->Query_Handle->Make_Query($serial_q, "fetch");
      if($existing_serial === false)
      {
        $this->Set_Error($this->SERIAL_QUERRY_ERROR);
        $this->Log_Error($this->Query_Handle->Query_Message());
        return false;
      }
      else if(!is_array($existing_serial))
      {
        $error = "RETURNED NON ARRAY SERIAL QUERRY";
        $this->Set_Error($error." VALUE: ".$existing_serial);
        $this->Log_Error($this->Query_Handle->Query_Message());
        return false;
      }
      else
      {
    		$num_inventories = count($existing_serial);
    		//$code = "0";
    		$code = $this->Calculate_Inventory_Num($num_inventories);
    		
    		$serial_code = $this->SERIAL_CODE.$code;
        if(in_array($serial_code, array_column($existing_serial, "serial_no")))
        {
          $this->Set_Error($this->SERIAL_COLLISION);
          //$this->Log_Error($this->Query_Handle->Query_Message());
          return false;
        }
        else
      		return $serial_code;
      }

  	}
  	public function Change_Serial_Code($new_code)
  	{
  		$this->SERIAL_CODE = $new_code;
  	}
  	public function Calculate_Inventory_Num($num_inventories)
  	{

  		if($num_inventories < 10)
  		{
  			$code = "000000".$num_inventories;
  		}
  		else if($num_inventories <100 && $num_inventories > 9)
  		{
  			$code = "00000".$num_inventories;
  		}
  		else if($num_inventories < 1000 && $num_inventories > 99)
  		{
  			$code = "0000".$num_inventories;
  		}
  		else if($num_inventories < 10000 && $num_inventories > 999)
  		{
  			$code = "000".$num_inventories;
  		}
  		else if($num_inventories < 100000 && $num_inventories > 9999)
  		{
  			$code = "00".$num_inventories;
  		}
  		else if($num_inventories < 1000000 && $num_inventories > 99999)
  		{
  			$code = "0".$num_inventories;
  		}
  		else 
  		{
  			$code = $num_inventories;
  		}
  		return $code;
  	}


    public function Get_Open_Inventory()
    {
      $query = "SELECT * FROM `inventory` 
      WHERE close_date IS NULL AND close_amount IS NULL";

      $inventory = $this->Query_Handle->Make_Query($query, "fetch");
      if($inventory === false)
      {
        $error = $this->Query_Handle->Query_Message();
        $this->Set_Error($this->SQL_ERROR);
        $this->Log_Error($error);
        return false;
      }
      else
        return $inventory;
    }

    public function Get_Given_Inventory($inv_id, $inv_token)
    {
      $query = "SELECT * FROM `inventory` 
      WHERE item_id = $inv_id AND item_token = '$inv_token'";

      $item_details = $this->Query_Handle->Make_Query($query, "fetch");
      if($item_details === false)
      {
        $error = $this->$Query_Handle->Query_Message();
        $this->Set_Error($this->SQL_ERROR);
        $this->Log_Error($error);
        return false;
      }
      else
        return $item_details;
    }

    public function Get_Sold($inv_id)
    {
      $query = "SELECT * FROM `inventory_closings` 
      WHERE inv_item_id = $inv_id";

      $sells = $this->Query_Handle->Make_Query($query, "fetch");
      if($sells === false)
      {
        $error = $this->Query_Handle->Query_Message();
        $this->Set_Error($SQL_ERROR);
        $this->Log_Error($error);
        return false;

      }
      else
        return $sells;
    }

    public function Sell_Inventory($details)
    {
      $
    }

}
?>