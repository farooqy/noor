<?php session_start();

if(isset($_POST['sold_to_id']) && isset($_POST['sold_to_name']))
{
	$requests = array(
		"sold_to_id","sold_to_name","sold_quan", "sold_price",
		"sold_desc","inv_id", "inv_token"
		);
	$req_types = array(
		"sold_to_id" => "int",
		"sold_to_name" => "string",
		"sold_quan" => "int",
		"sold_price" => "int",
		"sold_desc" => "string",
		"inv_id" => "int",
		"inv_token" =>"string"
		);
	$details = array();
	$num_requests = count($requests);
	$processed_reqs = 0;
	foreach ($requests as $key => $value) 
	{
		if(isset($_POST[$value]) === false)
		{
			echo json_encode(array(
				false,
				"Please fill all the required fields"
				));
			exit(0);
		}
		else
		{
			$temp = $_POST[$value];
			if($req_types[$value] === "int")
			{
				$details[$value] =filter_var($temp, FILTER_VALIDATE_INT);
				if($details[$value] === false)
				{
					echo json_encode(array(
						false,
						"The parameters are not of valid type"));
					exit(0);
				}
			}
			else
			{
				$details[$value] = filter_var($temp, FILTER_SANITIZE_STRING);
			}
			$processed_reqs++;
		}
	}
	if($processed_reqs !== $num_requests)
	{
		echo json_encode(array(
			false,
			"The requested parameters and the processed ones are not the same"));
		exit(0);
	}
	else
	{
		require_once("../classes/account.php");
		$Account = new Account();
		$is_valid_acc = $Account->Account_Exist($details["sold_to_id"]);
		if($is_valid_acc === false)
		{
			echo json_encode(array(
				false,
				"The account paid through is not valid account"));
			exit(0);
		}
		else if($is_valid_acc === "error")
		{
			echo json_encode(array(
				false,
				"Failed to validate the account paid throught: ".$Account->Get_Message()
				));
			exit(0);
		}
		require_once("../classes/inventory.php");
		$Inventory = new Inventory();
		$inv_id = $details["inv_id"];
		$inv_token = $details["inv_token"];
		$inv_details = $Inventory->Get_Given_Inventory($inv_id, $inv_token);
		if($inv_details === false)
		{
			echo json_encode(array(
				false,
				"Failed to validate the inventory details: ".$Inventory->Get_Message()
				));
			exit(0);
		}
		$prev_sell = $Inventory->Get_Sold($inv_id);
		$prev_quan = 0;
		if($prev_sell === false)
		{
			echo json_encode(array(
				false,
				"Failed to get the previous sells: ".$Inventory->Get_Message()
				));
			exit(0);
		}
		else
		{
			if(count($prev_sell) > 0)
			{
				$num_prev_sells = count($prev_sell);
				for($i=0; $i<$num_prev_sells; $i++)
				{
					$prev_quan += $prev_sell[$i]["sold_items"];
				}
			}
		}
		$quan_max = $prev_quan+$details["sold_quan"];
		if($inv_details[0]["item_quantity"] < $quan_max)
		{
			echo json_encode(array(
				false,
				"The quantity being sold exceeds the available quantity for sale"));
			exit(0);
		}
		$sales_account = $Account->Get_Account_By_Name("sales Account");
		if($sales_account === false)
		{
			echo json_encode(array(
				false,
				"could not find the Sales Account"
				));
		}
		else if(is_array($sales_account) === false)
		{

			echo json_encode(array(
				false,
				"Returned unknown data type of sales account"));
			exit(0);
		}
		else if(count($sales_account) > 1)
		{	

			echo json_encode(array(
				false,
				"Multiple sales account has been returned "));
			exit(0);
		}
		else
		{
			$time = time();
			$details["sell_date"] = $time;
			$details["cl_token"] = hash('md5', $time, false);
			$is_sold = $Inventory->Sell_Inventory($details);
		}
	}
} 
else
{
	echo json_encode(array(
		false,
		"You are lost in a generation full of maps"));
	exit(0);
}
?>