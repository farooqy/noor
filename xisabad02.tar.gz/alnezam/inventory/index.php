<?php session_start();
$home = "http://localhost/sites/alnezam/";

if(isset($_GET['inv']) && isset($_GET['token']))
{

	require_once("../classes/inventory.php");
	require_once("../classes/account.php");
	$Inventory = new Inventory();
	$inv_id = $_GET['inv'];
	$inv_id = filter_var($inv_id, FILTER_VALIDATE_INT);
	$inv_token = $_GET['token'];
	$inv_token = filter_var($inv_token, FILTER_SANITIZE_STRING);

	if($inv_id === false || empty($inv_token))
	{
		$error_trigger = 'The parameters of the inventory are not valid';
	}
	else
	{
		$inv_details = $Inventory->Get_Given_Inventory($inv_id, $inv_token);
		if($inv_details === false)
		{
			$error_trigger = 'Failed to get the inventory: '.$Inventory->Get_Message();
			unset($inv_details);
		}
		else
		{
			$sold_quantity = $Inventory->Get_Sold($inv_id);
			if($sold_quantity === false)
			{
				$error_trigger = "Failed to get the sold Quantity of this inventory";
				unset($inv_details);
				unset($sold_quantity);
			}
			else
			{
				$total_sells = 0;
				$num_sells = count($sold_quantity);
				if(count($num_sells > 0))
				{
					for($i=0; $i<$num_sells; $i++)
					{
						$total_sells += $sold_quantity[$i]["inv_sold"];
					}
				}
				$inv_details[0]["sold_items"] = $total_sells;
			}
		}
	}
}
else
{
	$error_trigger = 'There are no inventories to show with the request you have given';
}

$jquery = $home.'js/jQuery.js';
$btstrap = $home.'js/bootstrap.js';
$main = $home.'js/main.js';
$btmin = $home.'css/bootstrap.min.css';
$menu = $home.'css/menu.css';
$general = $home.'css/general.css';
$fcont = $home.'css/file_container.css';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Al Nezam Al Asasy</title>
	<meta charset="utf-8" lang="eng">
	<script type="text/javascript" src="<?php echo $jquery ?>"></script>
	<script type="text/javascript" src="<?php echo $btstrap ?>"></script>
	<script type="text/javascript" src="<?php echo $main?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo $btmin?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $menu ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $general ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $fcont ?>">
</head>
<body>
	<div class="container-fluid">
		<div class="row">
		<?php require_once('../menu.html');?>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4 col-lg-4">
				
				<form class="row inv_update_form" action="" method="POST">
					<div class="col-md-12 col-md-12">
						<?php
						$Account = new Account();
						$open_accs = $Account->Get_Open_Accounts();
						if($open_accs === false)
						{
							?>
							<div class="row">
								<?php echo 'ERROR: '.$Account->Get_Message(); ?>
							</div>
							<?php
						}
						else
						{
							$num_accs = count($open_accs);
							?>
							<div class="row main-bg display">
								<div class="col-md-1 col-lg-1"></div>
								<div class="col-md-10 col-lg-10">
									<div class="row mar-t-10 left-align fnt-oswald fnt-white">
										PAID THROUGH:
									</div>
									<div class="row">
										<select name="sold_to_id" class="col-md-12 col-lg-12">
											<option value="dft">SELECT ACCOUNT</option>
											<?php
										for($i=0; $i<$num_accs; $i++)
										{
											$acc_name = $open_accs[$i]["acc_name"];
											$acc_id = $open_accs[$i]["acc_id"];
											?>
											<option value="<?php echo $acc_id ?>" class="">
												<?php echo $acc_name ?>
											</option>
											<?php
										}
										?>
										</select>

									</div>
									<div class="row mar-t-10 mar-t-10 left-align fnt-oswald fnt-white">
										ENTITY NAME:
									</div>
									<div class="row">
										<input type="text" name="sold_to_name" class="input-text col-md-12 col-lg-12" placeholder="Quantity sold" max="<?php echo $inv_details[0]['item_quantity']; ?>">
									</div>
									<div class="row mar-t-10 mar-t-10 left-align fnt-oswald fnt-white">
										QUANTITY SOLD:
									</div>
									<div class="row">
										<input type="number" name="sold_quan" class="input-text col-md-12 col-lg-12" placeholder="Quantity sold" max="<?php echo $inv_details[0]['item_quantity']; ?>">
									</div>
									<div class="row mar-t-10 mar-t-10 left-align fnt-oswald fnt-white">
										SELLING PRICE:
									</div>
									<div class="row">
										<input type="number" name="sold_price" class=" input-text col-md-12 col-lg-12" placeholder="Price for each">
									</div>
									<div class="row mar-t-10 mar-t-10 left-align fnt-oswald fnt-white">
										DESCRIPTION:
									</div>
									<div class="row">
										<textarea name="sold_desc" class="col-md-12 col-lg-12 non-sizeable" placeholder="Description" rows='2'></textarea>
									</div>
									<div class="row">
										<input type="hidden" name="inv_id" value="<?php echo $inv_details[0]['item_id']; ?>">
										<input type="hidden" name="inv_token" value="<?php echo $inv_details[0]['item_token']; ?>">
									</div>
									<div class="row mar-t-10">
										<input type="submit" name="submit" value="Update" class="btn btn-primary">
										<input type="reset" name="submit" value="Reset" class="btn btn-danger">
									</div>

									<div class="row mar-t-10">
										<div class="col-md-2 col-lg-2"></div>
										<div class="col-md-8 col-lg-8 loader">
											<div class="row loader-text"></div>
											<div class="row loader-error"></div>
											<div class="row appendfiles"></div>
										</div>
										<div class="col-md-2 col-lg-2"></div>
									</div>
										
								</div>
									
								<div class="col-md-1 col-lg-1"></div>
							</div>

							<?php 
						}
						?>
					</div>	
				</form>
			</div>
			<div class="col-md-8 col-lg-8 main-bg display">
					<?php
					if(isset($error_trigger))
					{
						?>
						<div class="row err-div">
							<?php echo $error_trigger ?>
						</div>
						<?php
					}
					else
					{
						$item_name = $inv_details[0]["item_name"];
						$item_desc = $inv_details[0]["item_desc"];
						$item_quan = $inv_details[0]["item_quantity"];
						$item_price = $inv_details[0]["item_price"];
						$item_price = sprintf("%.2f", $item_price);
						$item_serail = $inv_details[0]["serial_no"];
						$total_amount = sprintf("%.2f",($item_price*$item_quan));
						$total_sold = $inv_details[0]["sold_items"];
						?>
						<table class="row table mar-t-20">
							<thead>
								<th>Serial Number</th>
								<th>Item Name</th>
								<th>Item Description</th>
								<th>Quantity</th>
								<th>Sold Quantity</th>
								<th>Price</th>
								<th>Total Amount</th>
							</thead>
							<tbody>
								<tr>
									<td><?php echo $item_serail ?></td>
									<td><?php echo $item_name ?></td>
									<td><?php echo $item_desc ?></td>
									<td><?php echo $item_quan ?></td>
									<td><?php echo $total_sold ?></td>
									<td><?php echo $item_price ?></td>
									<td><?php echo $total_amount ?></td>
								</tr>
							</tbody>
						</table>

						<div class="row ul fnt-oswald text-center fnt-white">
							<h2>Sells Details</h2>
						</div>
						<?php
						if($total_sold === 0)
						{
							?>
							<div class="row info-div text-center">
								The are no items sold in this inventory yet.
							</div>
							<?php
						}
						else
						{
							$num_sells = count($sold_quantity);
							?>
							<table class="row table">
								<thead>
									<th>#</th>
									<th>Date</th>
									<th>Concerned A/c </th>
									<th>Description</th>
									<th>Quantity sold</th>
									<th>Price</th>
									<th>Total</th>

								</thead>
								<?php
								
								$Account = new Account();
								for($i=0; $i<$num_sells; $i++)
								{
									$date = $sold_quantity[$i]["sold_date"];
									$date = gmdate('D M-d-Y', $date);
									$sold_to = $sold_quantity[$i]["sold_to_id"];
									$desc = $sold_quantity[$i]["sell_desc"];
									$sells_quan = $sold_quantity[$i]["inv_sold"];
									$sells_price = $sold_quantity[$i]["inv_sold_price"];
									$sells_price = sprintf("%.2f",$sells_price);
									$customer_details = $Account->Get_Account_Details($sold_to);
									if($customer_details === false)
									{
										$error_trigger = "Failed to get the customer details";
										$customer_details[0]["acc_name"] = "UNKNOWN!";
										$link = $home."accounts?account=-1&token=None&dir=-1";
									}
									else
									{
										$cust_token = $customer_details[0]["acc_token"];
										$cust_dir = $customer_details[0]["acc_folder"];
										$link = $home."accounts?account=".$sold_to."&token=".$cust_token."&dir=".$cust_dir;
									}
									$cust_name = $customer_details[0]["acc_name"];
									?>
									<tbody>
										<tr>
											<td><?php echo ($i+1) ?></td>
											<td><?php echo $date ?></td>
											<td>
												<a href="<?php echo $link ?>" class="fnt-black">
													<?php echo $cust_name ?>
												</a>
											</td>
											<td><?php echo $desc ?></td>
											<td><?php echo $sells_quan ?></td>
											<td><?php echo $sells_price ?></td>
											<td><?php echo ($sells_price*$sells_quan) ?></td>

										</tr>
									</tbody>
									<?php
								} 
								?>
							</table>
							<?php
						}
					}
					?>
			</div>
		</div>
	</div>
</body>
</html>
