<?php session_start();
require_once("classes/folder.php");
if(isset($_POST["folder_name"]))
{
	$folder = $_POST["folder_name"];
	$folder = filter_var($folder, FILTER_SANITIZE_STRING);
	$parent = $_POST["parent"];
	$parent = filter_var($parent, FILTER_VALIDATE_INT);
	$parent_name = $_POST["parent_di"];
	$parent_name = filter_var($parent_name, FILTER_SANITIZE_STRING);
	$level = $_POST["level"];
	$level = filter_var($level);

	if(empty($folder) || empty($parent) )
	{
		$error = "The folders names cannot be empty ";
		echo json_encode(array(false, $error));
		exit(0);
	}
	else if($level === "dft")
	{
		$error = "Please choose the people who can see this folder";
		echo json_encode(array(false, $error));
		exit(0);
	}
	else if($level !== "all" && $level !== "admin")
	{
		$error = "The visibility type is not recognized";
		echo json_encode(array(false, $error));
		exit(0);
	}
	//echo json_encode(array(true,"success"));
	$Folder_Handle = new Folder();
	$details = array(
		"name" => $folder,
		"parent" => $parent,
		"visible" => $level
		);
	$Folder_Handle->Set_Folder_Details($details);
	$is_saved = $Folder_Handle->Save_Folder();
	if($is_saved)
	{
		echo json_encode(array(true, "success"));
		exit(0);
	}
	else
	{
		$error = $Folder_Handle->Get_Message();
		echo json_encode(array(false, $error));
		exit(0);
	}

}
else
{
	echo json_encode(array(false, "No data"));
	exit(0);
}
?>