<?php session_start();
$home = "http://localhost/sites/alnezam/";
$company = "AL NEZAM AL ASASY GENERAL TRADING LLC";
$comp_location = "KUWAIT BUILDING,DEIRA,DUBAI, UAE";
$pobox = "40450 DEIRA DUBAI";
$tel = "+971504282657";
$email = "alnezam.alasasy@gmail.com";
$extra = "";
if(isset($_GET['inv_num']) && isset($_GET['inv_token']))
{
	$inv_num = $_GET['inv_num'];
	$inv_num = filter_var($inv_num, FILTER_SANITIZE_STRING);
	$inv_token =$_GET['inv_token'];
	$inv_token = filter_var($inv_token, FILTER_SANITIZE_STRING);

	if($inv_num === false)
	{
		$error_trigger = 'The parameters are not valid';
	}
	else
	{
		require_once('../classes/invoice.php');
		$Invoices = new Invoice();
		$given_inv = $Invoices->Get_Given_Inv($inv_num, $inv_token);
		if($given_inv === false)
		{
			$error_trigger = 'Error getting invoice: '.$Invoices->Get_Message();

		}
		else if(count($given_inv) <= 0)
		{
			$error_trigger = 'The invoice number you have given does not exist';
		}
		else
		{
			//given invoice is found
		}
	}
}
$jquery = $home.'js/jQuery.js';
$btstrap = $home.'js/bootstrap.js';
$main = $home.'js/main.js';
$btmin = $home.'css/bootstrap.min.css';
$menu = $home.'css/menu.css';
$general = $home.'css/general.css';
$fcont = $home.'css/file_container.css';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Al Nezam Al Asasy</title>
	<meta charset="utf-8" lang="eng">
	<script type="text/javascript" src="<?php echo $jquery ?>"></script>
	<script type="text/javascript" src="<?php echo $btstrap ?>"></script>
	<script type="text/javascript" src="<?php echo $main?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo $btmin?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $menu ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $general ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $fcont ?>">
</head>
<body>
	<div class="container-fluid">
		<div class="row">
		<?php require_once('../menu.html');?>
		</div>
	</div>
	<div class="container">
		<div class="row mar-t-10">
			<div class="col-md-12 col-lg-12 inv-frame">
				<?php
				if(isset($error_trigger))
				{
					?>
					<div class="row err-div">
						<?php echo $error_trigger; ?>
					</div>
					<?php
				}
				else if(isset($given_inv))
				{
					?>
					<div class="row">
						<div class="col-md-8 col-lg-8">
							<div class="row mar-t-10 c-name fnt-share ul">
								<h3><?php echo $company; ?></h3>
							</div>
							<div class="row mar-t-10 c-name fnt-oswald">
								LOCATION: <?php echo $comp_location; ?>
							</div>
							<div class="row mar-t-10 c-name fnt-oswald">
								P.O.BOX: <?php echo $pobox; ?>
							</div>
							<div class="row mar-t-10 c-name fnt-oswald">
								TELEPHONE: <?php echo $tel; ?>
							</div>
							<div class="row mar-t-10 c-name fnt-oswald">
								EMAIL: <?php echo $email; ?>
							</div>
							<div class="row mar-t-10 c-name fnt-oswald">
								OTHER INFO: <?php echo $extra; ?>
							</div>
						</div>
						<div class="col-md-4 col-lg-4">
							<div class="row fnt-russo ul mar-t-10 fnt-22">INVOICE: 
							</div>
							<table class="table row">
								<thead>
									<th>Date</th>
									<th>Invoice No</th>
								</thead>
								<tbody>
									<tr>
										<td>
											<?php
											$date = $given_inv[0]["inv_date"];
											$date = gmdate('D- M-d-Y',$date);
											echo $date;  
											?>
										</td>
										<td><?php
										echo $given_inv[0]["inv_no"]; 
										?></td>
									</tr>
								</tbody>
							</table>
							
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 col-lg-6">
							<table class="row table">
								<thead>
									<th>Bill To</th>
								</thead>
								<tbody>
									<tr>
										<td>
											<?php echo $given_inv[0]["inv_holder"]; ?>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="col-md-6 col-lg-6 fnt-share mar-t-20 text-center ul">
							Thank You for your business
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 col-lg-12">
							<?php
							$num_items =  count($given_inv);
							?>
							<table class="row inv-table">
								<thead>
									<th>#</th>
									<th>Description</th>
									<th>Quantity</th>
									<th>Price</th>
									<th>Total</th>
								</thead>
								<tbody>
									<?php
									$sum_inv = 0;

								for($i=0; $i<$num_items; $i++)
								{
									$desc = $given_inv[$i]["inv_item_desc"];
									$quan = $given_inv[$i]["inv_item_quan"];
									$price = $given_inv[$i]["inv_item_price"];
									$price = sprintf('%.2f',$price);
									$total = $quan * $price;
									$total = sprintf("%.2f",$total);
									$sum_inv += $total;
									?>
									<tr>
										<td><?php echo $i+1 ?></td>
										<td><?php echo $desc ?></td>
										<td><?php echo $quan ?></td>
										<td><?php echo $price ?></td>
										<td><?php echo $total ?></td>
									</tr>
									<?php
								}
								?>
								</tbody>
							</table>
							
						</div>
					</div>
					<div class="row mar-t-20">
						<div class="col-md-8 col-lg-8"></div>
						<div class="col-md-4 col-lg-4">
							<table class="row table">
								<thead>
									<th>Number of Items</th>
									<th> Total Amount </th>
								</thead>
								<tbody>
									<tr>
										<td><?php echo $num_items?>
											Item(s)
										</td>
										<td><?php echo sprintf("%.2f",$sum_inv); ?></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
							
					<?php
				}
				else
				{
					?>
					<div class="row err-div text-center">
						There are no invoices to show
					</div>
					<?php
				}
				?>
			</div>
		</div>
	</div>
</body>
</html>