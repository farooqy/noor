<?php session_start();
$home = "http://localhost/sites/alnezam/";

require_once("../classes/ledger.php");
require_once("../classes/account.php");
$Ledger = new Ledger();
$Account = new Account();
$all_accs = $Ledger->Get_Journal();
$accounts_balances = array();
if($all_accs === false)
{
	unset($accounts_balances);
	$error_trigger = 'Failed to get the accounts:
	 '.$Ledger->Get_Message();
}
else
{
	$num_trans = count($all_accs);
	for($i=0; $i<$num_trans; $i++)
	{
		$id = $all_accs[$i]["cash_id"];
		$amount = $all_accs[$i]["cash_amount"];
		$acc_from = $all_accs[$i]["cash_trans_from"];
		$acc_to = $all_accs[$i]["cash_trans_to"];
		$current_acc = array_column($accounts_balances, "acc_id");
		//print_r($current_acc);
		//echo '<br>';
		$acc_from_name = $Account->Get_Account_Detail($acc_from);
		$acc_to_name = $Account->Get_Account_Detail($acc_to);
		if($acc_from_name === false)
		{
			$error_trigger = 'Failed to get one of the account details for the debiters';
			break;
		}
		else if($acc_to_name === false)
		{
			$error_trigger = 'Failed to get one of the account details for the creditors';
			break;
		}
		if(in_array($acc_to, $current_acc) === true)
		{
			$key = array_search($acc_to, $current_acc);
			$accounts_balances[$key]["debit"] +=$amount;
		}
		else
		{
			$new_acc = array(
				"acc_id" => $acc_to,
				"debit" => $amount,
				"credit" => 0,
				"name" => $acc_to_name[0]["acc_name"],
				"acc_token" => $acc_to_name[0]["acc_token"],
				);
			array_push($accounts_balances, $new_acc);
		}
		if(in_array($acc_from, $current_acc) === true)
		{
			$key = array_search($acc_from, $current_acc);
			$accounts_balances[$key]["credit"] +=$amount;
		}
		else
		{
			$new_acc = array(
				"acc_id" => $acc_from,
				"credit" => $amount,
				"debit" => 0,
				"name" => $acc_from_name[0]["acc_name"],
				"acc_token" => $acc_from_name[0]["acc_token"],
				);
			array_push($accounts_balances, $new_acc);

		}
	}
}

$jquery = $home.'js/jQuery.js';
$btstrap = $home.'js/bootstrap.js';
$main = $home.'js/main.js';
$btmin = $home.'css/bootstrap.min.css';
$menu = $home.'css/menu.css';
$general = $home.'css/general.css';
$fcont = $home.'css/file_container.css';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Al Nezam Al Asasy</title>
	<meta charset="utf-8" lang="eng">
	<script type="text/javascript" src="<?php echo $jquery ?>"></script>
	<script type="text/javascript" src="<?php echo $btstrap ?>"></script>
	<script type="text/javascript" src="<?php echo $main?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo $btmin?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $menu ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $general ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $fcont ?>">
</head>
<body>
	<div class="container-fluid">
		<div class="row">
		<?php require_once('../menu.html');?>
		</div>
	</div>
	<div class="container">
	<?php
	if(isset($error_trigger))
	{
		?>
		<div class="row err-div">
			<?php echo $error_trigger ?>
		</div>
		<?php
	}
	else
	{
		?>
		<table class="row table mar-t-20">
			<thead>
				<th>#</th>
				<th>Account Name</th>
				<th>Debit</th>
				<th>Credit</th>
			</thead>
			<tbody>
			<?php
			$num_accs = count($accounts_balances);
			$total_trial_debit = 0 ;
			$total_trial_credit = 0;
			for($i=0; $i<$num_accs; $i++)
			{
				$debit_total = $accounts_balances[$i]["debit"];
				$credit_total = $accounts_balances[$i]["credit"];
				$acc_name = $accounts_balances[$i]["name"];
				$token = $accounts_balances[$i]["acc_token"];
				$acc_id = $accounts_balances[$i]["acc_id"];
				$link = $home."accounts?account=".$acc_id."&token=".$token;
				$total_trial_credit += $credit_total;
				$total_trial_debit += $debit_total;
				?>
				<tr>
					<td><?php echo ($i+1) ?></td>
					<td><?php echo $acc_name ?></td>
					<?php
					if($debit_total > $credit_total)
					{
						echo "<td>".($debit_total-$credit_total)."</td> 
						<td> - </td>";
					}
					else
					{
						echo "<td> - </td> <td>".($credit_total-$debit_total)."</td>";
					}
					?>
				</tr>
				<?php 
			}
			?>
			</tbody>
		</table>
		<div class="row">
			<div class="col-md-6 col-lg-6">
				<div class="row info-div text-center mar-t-20">
					<?php
					if($total_trial_debit != $total_trial_credit)
					{
						?>
						<div class="col-md-12 col-lg-12 err-div">
							The balances of the accounts don't sum up equally. This indicates possible error in the ledgers, please revise the books.
						</div>
						<?php
					}
					else
					{
						echo 'The balances of the accounts sum up equally. This indicates correct ledgers';
					}
					?>
				</div>
			</div>
			<div class="col-md-2 col-lg-2"></div>
			<div class="col-md-4 col-lg-4">
				<table class="row table mar-t-20">
					<thead>
						<th>Total Debit</th>
						<th>Total Credit</th>
					</thead>
					<tbody>
						<tr>
							<td>
								<?php
								echo $total_trial_debit;
								?>
							</td>
							<td>
								<?php
								echo $total_trial_credit;
								?>
							</td>
						</tr>
					</tbody>
					<?php

					?>
				</table>
				
			</div>
		</div>
		<?php
	}
	?>
	</div>
</body>
</html>