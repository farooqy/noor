<?php 

require_once("database.php");
require_once("query_handle.php");
require_once("logger.php");
class Account {
	//account attributes
	protected $acc_id = null;
	protected $acc_name = null;
	protected $acc_type = null;
	protected $acc_desc = null;
	protected $acc_date = null;
	protected $acc_token = null;
	protected $acc_status = null;
	protected $acc_dir = null;

	//object attributes
	protected $is_isset = false;

	//error attributes
	protected $error_status = False; 
	protected $error_message = "No Folder Error";
	protected $error_file = "folder_errors";
	protected $Logger = null;
	private $PERMISSIN_DENIED_ERROR = "You do not have permission to 
	create an account in this directory";
	private $SQL_ERROR = "The query to process your request contains an 
	error, please contact administrator";
	private $DETAILS_NOT_SET_ERROR = "The acount details are not set";
	private $EXIST_FAILED_ERROR = "Failed to check the existence of the user ";

	//db connection attributes
	protected $conn = ""; //hold the db query arrow 
	protected $db = "";//holds the database object
	protected $db_status = false; //not conencted initially
	private $Query_Handle = null;

	public function __construct()
  	{
  		$this->error_file = "account.error";
  		$this->Logger = new Logger($this->error_file);
    	$this->db = new connection();
	    $status = $this->db->connection_status();
	    if($status)
	    {
	      $this->conn = $this->db->connection();
	      $this->db_status = true; //db connection success
	      $this->Query_Handle =new Query_Handle($this->db->connection());
	    }
	    else
	    {
	      $this->error_status = true;
	      $this->error_message = "Connection failed";
	    }
  	}
	public function Db_Status()
	{
		return $this->db_status;
	}
	  
	public function Get_Message()
	{
		return $this->error_message;
	}
	public function Set_Error($error)
	{
		$this->error_status = true;
		$this->error_message = $error;
	}
	public function Log_Error($error)
	{
		if($this->Logger->Initial_Error() === true)
		{
			$error = $this->error_message." Logging Intial failed: 
			".$this->Logger->Failed_Message()." MAIN ERROR: ".$error;
			$this->Set_Error($error);
		}
		else
		{
			$is_logged = $this->Logger->Write_Error($error);
			if($is_logged === false)
			{
				$error = $this->error_message." Logging failed: 
				".$this->Logger->Failed_Message()." MAIN ERROR: ".$error;
				$this->Set_Error($error);
			}
		}
	}

	public function Set_Acc_Details($details)
	{
		$time = time();
		$this->acc_name = $details["acc_name"];
		$this->acc_type = $details["acc_type"];
		$this->acc_desc = $details["acc_desc"];
		$this->acc_dir = $details["acc_dir"];
		$this->acc_date = $time;
		$this->acc_token = hash('md5', $time, false);
		$this->acc_status = 'active';

		$this->is_isset = true;
	}
	
	public function Save_Account()
	{
		if($this->is_isset === false)
		{
			$this->Set_Error($DETAILS_NOT_SET_ERROR);
			return false;
		}
		else
		{
			$query = "INSERT INTO `accounts` (
			acc_name, acc_type, acc_desc, acc_date,
			acc_token, acc_status,acc_folder)
			VALUES('$this->acc_name', '$this->acc_type', 
			'$this->acc_desc', $this->acc_date,
			'$this->acc_token', 'active', $this->acc_dir)";

			$is_saved = $this->Query_Handle->Make_Query($query);
			if($is_saved === true) 
			{
				return true;
			}
			else
			{
				$error = $this->Query_Handle->Query_Message();
				$this->Set_Error($this->SQL_ERROR);
				$this->Log_Error($error);
				return false;
			}
		}
	}

	public function Get_Open_Accounts()
	{
		$query = "SELECT * FROM `accounts` 
		WHERE acc_status = 'active' ORDER BY acc_name ";

		$acc_list = $this->Query_Handle->Make_Query($query, "fetch");
		if($acc_list === false)
		{
			$error = $this->Query_Handle->Query_Message();
			$this->Set_Error($this->SQL_ERROR);
			$this->Log_Error($error);
			return false;
		}
		return $acc_list;
	}

	public function Get_Account($acc_token,$acc_id)
	{
		$query = "SELECT acc_id, acc_status, acc_type, acc_name, acc_desc FROM `accounts` 
		WHERE acc_id = $acc_id AND acc_token = '$acc_token'";

		$acc = $this->Query_Handle->Make_Query($query, "fetch");
		if($acc === false)
		{
			$error = $this->Query_Handle->Query_Message();
			$this->Set_Error($this->SQL_ERROR);
			$this->Log_Error($error);
			return false;
		}
		return $acc;
	}
	public function Get_Ledger($tran_id)
	{
		$query = "SELECT * FROM `dcash` 
		WHERE cash_trans_from = $tran_id || cash_trans_to = $tran_id 
		ORDER BY cash_date ";
		$ledger = $this->Query_Handle->Make_Query($query, "fetch");
		if($ledger === false)
		{
			$error = $this->Query_Handle->Query_Message();
			$this->Set_Error($this->SQL_ERROR);
			$this->Log_Error($error);
			return false;
		}
		return $ledger;
	}
	public function Account_Exist($acc_id)
	{
		$query = "SELECT * FROM `accounts` 
		WHERE acc_id = $acc_id";
		$acc = $this->Query_Handle->Make_Query($query, "fetch");
		if($acc === false)
		{
			$error = $this->Query_Handle->Query_Message();
			$this->Set_Error($this->SQL_ERROR);
			$this->Log_Error($error);
			return 'error';
		}
		else if(is_array($acc) === false)
		{
			$this->Set_Error('Uknown data returned');
			return 'error';
		}
		else if(count($acc) === 1)
		{
			return true;
		}
		else
			return false;
	}
	public function Get_Account_Detail($acc_id)
	{
		$query = "SELECT * FROM `accounts` 
		WHERE acc_id = $acc_id";

		$acc = $this->Query_Handle->Make_Query($query, "fetch");
		if($acc === false)
		{
			$error = $this->Query_Handle->Query_Message();
			$this->Set_Error($this->SQL_ERROR);
			$this->Log_Error($error);
			return false;
		}
		else
			return $acc;
	}
}
?>