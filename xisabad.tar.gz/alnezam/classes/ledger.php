<?php 

require_once("database.php");
require_once("query_handle.php");
require_once("logger.php");
class Ledger {
	//ledger attributes
	protected $ldg_id = null;
	protected $ldg_dcash_id = null;
	protected $ldg_type = null;
	protected $ldg_amount = null;
	protected $ldg_status = null;

	//journal attributes
	protected $cash_id = null;
	protected $cash_date = null;
	protected $cash_desc = null;
	protected $cash_type = null; //cash or cheque
	protected $cash_cheq_no = null; 
	protected $cash_amount = null;
	protected $cash_status = null;
	protected $cash_token = null;
	protected $cash_trans_from = null;
	protected $cash_trans_to = null;
	//object attributes
	protected $ldg_is_isset = false;
	protected $cash_is_isset = false;

	//error attributes
	protected $error_status = False; 
	protected $error_message = "No Folder Error";
	protected $error_file = "folder_errors";
	protected $Logger = null;
	private $PERMISSIN_DENIED_ERROR = "You do not have permission to 
	create an account in this directory";
	private $SQL_ERROR = "The query to process your request contains an 
	error, please contact administrator";
	private $DETAILS_NOT_SET_ERROR = "The acount details are not set";
	private $EXIST_FAILED_ERROR = "Failed to check the existence of the user ";

	//db connection attributes
	protected $conn = ""; //hold the db query arrow 
	protected $db = "";//holds the database object
	protected $db_status = false; //not conencted initially
	private $Query_Handle = null;

	public function __construct()
  	{
  		$this->error_file = "account.error";
  		$this->Logger = new Logger($this->error_file);
    	$this->db = new connection();
	    $status = $this->db->connection_status();
	    if($status)
	    {
	      $this->conn = $this->db->connection();
	      $this->db_status = true; //db connection success
	      $this->Query_Handle =new Query_Handle($this->db->connection());
	    }
	    else
	    {
	      $this->error_status = true;
	      $this->error_message = "Connection failed";
	    }
  	}
	public function Db_Status()
	{
		return $this->db_status;
	}
	  
	public function Get_Message()
	{
		return $this->error_message;
	}
	public function Set_Error($error)
	{
		$this->error_status = true;
		$this->error_message = $error;
	}
	public function Log_Error($error)
	{
		if($this->Logger->Initial_Error() === true)
		{
			$error = $this->error_message." Logging Intial failed: 
			".$this->Logger->Failed_Message()." MAIN ERROR: ".$error;
			$this->Set_Error($error);
		}
		else
		{
			$is_logged = $this->Logger->Write_Error($error);
			if($is_logged === false)
			{
				$error = $this->error_message." Logging failed: 
				".$this->Logger->Failed_Message()." MAIN ERROR: ".$error;
				$this->Set_Error($error);
			}
		}
	}

	public function Set_ldg_Details($details)
	{
		$this->ldg_dcash_id = $details["ldg_dcash_id"];
		$this->ldg_type = $details["ldg_type"];
		$this->ldg_amount = $details["ldg_amount"];
		$this->ldg_is_isset = true;
	}
	public function Set_Cash_details($details)
	{
		$time = time();
		$this->cash_date = $details["cash_trans_date"];
		$this->cash_desc = $details["cash_desc"];
		$this->cash_type = $details["cash_type"];
		$this->cash_cheq_no = $details["cash_cheq_no"];
		$this->cash_amount = $details["cash_amount"];
		$this->cash_token = hash('md5', $time, false);
		$this->cash_trans_from = $details["cash_trans_from"];
		$this->cash_trans_to = $details["cash_trans_to"];

		$this->cash_is__isset = true;
	}
	
	public function Save_Ledger()
	{
		if($this->ldg_is__isset === false)
		{
			$this->Set_Error($DETAILS_NOT_SET_ERROR);
			return false;
		}
		else
		{
			$query = "INSERT INTO `ledger` (
			ldg_dcash_id, ldg_type, ldg_amount, ldg_status)
			VALUES($this->ldg_dcash_id, '$this->ldg_type',
			$this->ldg_amount, 'active')";

			$is_saved = $this->Query_Handle->Make_Query($query);
			if($is_saved === true) 
			{
				return true;
			}
			else
			{
				$error = $this->Query_Handle->Query_Message();
				$this->Set_Error($this->SQL_ERROR);
				$this->Log_Error($error);
				return false;
			}
		}
	}
	public function Save_Journal()
	{
		if($this->cash_is__isset === false)
		{
			$this->Set_Error($DETAILS_NOT_SET_ERROR);
			return false;
		}
		else
		{

			$query = "INSERT INTO `dcash` ( cash_date, cash_desc, cash_type, cash_cheq_no, cash_amount,  cash_status,cash_token, cash_trans_from, cash_trans_to)
			VALUES($this->cash_date, 
			'$this->cash_desc',
			'$this->cash_type', $this->cash_cheq_no, $this->cash_amount,
			'active','$this->cash_token', 
			$this->cash_trans_from, $this->cash_trans_to)";

			$is_saved = $this->Query_Handle->Make_Query($query);
			if($is_saved === true) 
			{
				return true;
			}
			else
			{
				$error = $this->Query_Handle->Query_Message();
				$this->Set_Error($this->SQL_ERROR);
				$this->Log_Error($error);
				return false;
			}
		}
	}

	public function Get_Given_Trans_Id($args)
	{
		$condition = "";
		$first_time = true;
		foreach ($args as $key => $value) {
			if($first_time)
				{
					$condition = "$key = $value ";
					$first_time = false;
				}
			else
				$condition .= "AND $key = $value ";
		}
		$query = "SELECT cash_id FROM `dcash` WHERE $condition ";

		$id = $this->Query_Handle->Make_Query($query, "fetch");
		if($id === false)
		{
			$error = $this->Query_Handle->Query_Message();
			$this->Set_Error($this->SQL_ERROR);
			$this->Log_Error($error);
			return false;
		}
		else
			return $id;
	}

	public function Debit_Account($cash_id, $amount, $acc_id, $token)
	{
		$query = "INSERT INTO `ledger` (ldg_dcash_id, ldg_type, 
		ldg_amount, ldg_status, ldg_token) 
		VALUES($cash_id, 'debit', $amount, 'active', '$token')";

		$is_debited = $this->Query_Handle->Make_Query($query);
		if($is_debited === false)
		{
			$error = $Query_Handle->Query_Message();
			$this->Set_Error($this->SQL_ERROR);
			$this->Log_Error($error);
			return false;
		}
		else
			return true;
	}

	public function Credit_Account($cash_id, $amount, $acc_id, $token)
	{
		$query = "INSERT INTO `ledger` (ldg_dcash_id, ldg_type, 
		ldg_amount, ldg_status, ldg_token) 
		VALUES($cash_id, 'credit', $amount, 'active', '$token')";

		$is_credited = $this->Query_Handle->Make_Query($query);
		if($is_credited === false)
		{
			$error = $Query_Handle->Query_Message();
			$this->Set_Error($this->SQL_ERROR);
			$this->Log_Error($error);
			return false;
		}
		else
			return true;
	}
	public function Detele_Record($table, $column, $value)
	{
		if(is_string($value))
		{
			$condition = "WHERE $column = '$value'";
		}
		else
		{
			$condition = "WHERE $column = $value ";
		}

		$query = "DELETE FROM `$table` WHERE $condition ";
		$is_deleted = $this->Query_Handle->Make_Query($query);
		if($is_deleted === false)
		{
			$error = $this->Query_Handle->Query_Message();
			$this->Set_Error($this->SQL_ERROR);
			$this->Log_Error($error);
			return false;
		}
		else
			return true;
	}
	public function Get_Journal()
	{
		$query = "SELECT * FROM `dcash` WHERE 1 ORDER BY cash_date";
		$journal = $this->Query_Handle->Make_Query($query, "fetch");
		if($journal === false)
		{
			$error = $this->Query_Handle->Query_Message();
			$this->Set_Error($this->SQL_ERROR);
			$this->Log_Error($error);
			return false;
		}
		else
			return $journal;
	}
}
?>