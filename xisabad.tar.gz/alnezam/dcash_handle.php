<?php session_start();

if(isset($_POST['cash_effect']))
{
	//echo json_encode(array(false,'ok'));
	$params = array(
		"cash_effect" => "The account from the transactin ",
		"cash_effect_to" => "The account to the transactin ",
		"cash_desc" => "The transaction description ",
		"cash_type" => "The payment method ",
		"trans_amount" => "The amount ");
	foreach ($params as $key => $value) {
		if(isset($_POST[$key]) === false)
		{
			echo json_encode(array(
				false,
				"The $value must be filled "
				));
			exit(0);
		}
		else if($_POST[$key] === 'dft' || empty($_POST[$key]))
		{
			echo json_encode(array(
				false,
				"The $value is empty, it must be filled "
				));
			exit(0);
		}
		else if($_POST[$key] === 'cheque' && isset($_POST['cheq_num']) === false)
		{
			echo json_encode(array(
				false,
				'The cheque number must be filled '
				));
			exit(0);
		}
	}

	$cash_effect = $_POST['cash_effect'];
	$cash_effect = filter_var($cash_effect, FILTER_VALIDATE_INT);
	$cash_effect_to = $_POST['cash_effect_to'];
	$cash_effect_to = filter_var($cash_effect_to, FILTER_VALIDATE_INT);
	$cash_desc = $_POST['cash_desc'];
	$cash_desc = filter_var($cash_desc, FILTER_SANITIZE_STRING);
	$cash_type = $_POST['cash_type'];
	$cash_type = filter_var($cash_type, FILTER_SANITIZE_STRING);
	$trans_amount = $_POST['trans_amount'];
	$trans_amount = filter_var($trans_amount, FILTER_VALIDATE_INT);
	$cheq_num = 0;
	if($cash_effect === false || $cash_effect <= 0)
	{
		echo json_encode(array(
			false,
			"The account where the transaction is credited FROM must be valid account"
			));
		exit(0);
	}
	if($cash_effect_to === false || $cash_effect_to <= 0)
	{
		echo json_encode(array(
			false,
			"The account where the transaction is debited TO must be valid account"
			));
		exit(0);
	}
	if($cash_effect === $cash_effect_to)
	{
		echo json_encode(array(
			false,
			"The account FROM the transaction cannot be the same as the account TO the transaction "
			));
		exit(0);
	}
	if($cash_type !== 'cash' && $cash_type !== 'cheque')
	{
		echo json_encode(array(
			false,
			'The cash type must be either cash or cheque'
			));
		exit(0);
	}
	if($cash_type === 'cheque')
	{
		$cheq_num = $_POST['cheq_num'];
		$cheq_num = filter_var($cheq_num, FILTER_VALIDATE_INT);
		if($cheq_num === false || $cheq_num <= 99999)
		{
			echo json_encode(array(
				false,
				'The cheque number must be valid 6 digit number'
				));
			exit(0);
		}
	}
	if($trans_amount === false || $trans_amount <= 0)
	{
		echo json_encode(array(
			false,
			'The transaction amount is not valid '
			));
		exit(0);
	}
	require_once("classes/account.php");
	$Account = new Account();
	$isvalid_account = $Account->Account_Exist($cash_effect);
	if($isvalid_account === false)
	{
		echo json_encode(array(
			false,
			"The account for the debit transaction is not valid"
			));
		exit(0);
	}
	else if($isvalid_account === 'error')
	{
		echo json_encode(array(
			false,
			$Account->Get_Message()
			));
		exit(0);
	}
	$isvalid_account = $Account->Account_Exist($cash_effect_to);
	if($isvalid_account === false)
	{
		echo json_encode(array(
			false,
			"The account for the credit transaction is not valid"
			));
		exit(0);
	}
	else if($isvalid_account === 'error')
	{
		echo json_encode(array(
			false,
			$Account->Get_Message()
			));
		exit(0);
	}
	require_once("classes/ledger.php");
	$Ledger = new Ledger();
	$time = time();
	$cash_details = array(
		"cash_desc" => $cash_desc,
		"cash_type" => $cash_type,
		"cash_cheq_no" => $cheq_num,
		"cash_amount" => $trans_amount,
		"cash_trans_from" => $cash_effect,
		"cash_trans_to" => $cash_effect_to,
		"cash_trans_date" => $time 
		);
	$Ledger->Set_Cash_Details($cash_details);
	$cash_is_saved = $Ledger->Save_Journal();
	if($cash_is_saved === true)
	{
		$args = array("cash_date"=> $cash_details["cash_trans_date"],
					  "cash_trans_from" =>$cash_effect);
		$ldg_info = $Ledger->Get_Given_Trans_Id($args);
		if($ldg_info === false)
		{
			echo json_encode(array(
				false,
				'Failed to save: '.$Ledger->Get_Message()
				));
			exit(0);
		}
		else if(is_array($ldg_info) === false)
		{
			echo json_encode(array(
				false,
				"Returned a non array type while getting ledger info"
				));
			exit(0);
		}
		else if(count($ldg_info) <= 0)
		{
			echo json_encode(array(
				false,
				'CRITICAL: FAILED TO GET A LEDGER THAT HAS BEEN SAVED IN THE JOURNAL'
				));
			exit(0);
		}
		else if(count($ldg_info) > 1)
		{
			echo json_encode(array(
				false,
				'Returned multiple journals for a single entry'
				));
			exit(0);
		}
		else
		{
			$cash_id = $ldg_info[0]["cash_id"];
			$debit_token = hash('md5', time(), false);
			$is_debited = $Ledger->Debit_Account($cash_id, $trans_amount, $cash_effect, $debit_token);
			if($is_debited === true)
			{
				$credit_token = hash('md5', time(), false);
				$is_credited = $Ledger->Credit_Account($cash_id, $trans_amount, $cash_effect_to, $credit_token);
				if($is_credited === true)
				{
					echo json_encode(array(
						true,
						"success"
						));
				}
				else
				{
					$table = 'ledger';
					$column = 'ldg_token';
					$undo_debit = $Ledger->Delete_Record($table, $column, $credit_token);
					if($undo_debit === false)
					{
						echo json_encode(array(
							false,
							"Account failed to be credited and debit could not be undone"
							));
						exit(0);
					}
					else
					{
						echo json_encode(array(
							false,
							"The account To credit failed, please contact admin"
							));
						exit(0);
					}
				}
			}
			else
			{

				$table = 'ledger';
				$column = 'ldg_token';
				$undo_journal = $Ledger->Delete_Record($table, $column, $debit_token);
				if($undo_journal === false)
				{
					echo json_encode(array(
						false,
						"Failed to debit account and the journal failed to be undone"
						));
					exit(0);
				}
				else
				{
					echo json_encode(array(
						false,
						"Failed to debit account, please contact admin"
						));
					exit(0);
				}
					
			}
		}
			
	}
	else
	{
		echo json_encode(array(
			false,
			$Account->Get_Message()
			));
	}
	


}
else
{
	echo json_encode(array(
		false,
		'Its 2018, a year to be true and stop fucking around'
		));
}
?>