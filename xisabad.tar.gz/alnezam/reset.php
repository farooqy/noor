<?php session_start();
if(isset($_SESSION["success_files"]))
{
	$files = $_SESSION["success_files"];
	print_r($files);
	for($i=0; $i<count($files); $i++)
	{
		unlink($files[$i]["dir"]);
	}
	$_SESSION["success_files"] = null;
	unset($_SESSION["success_files"]);
	echo json_encode(array(true, "Form is reset"));
} 
?>