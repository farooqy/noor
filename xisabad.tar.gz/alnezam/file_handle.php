<?php session_start();
//TO DO:: retrieve all folder from db to ensure the 
//passed folder is authentic
$url_path = "http://localhost/sites/alnezam/";
$home_dir = "/var/www/html/sites/alnezam/";
if(isset($_POST["type"]) && isset($_FILES["upload_file"]))
{
	//print_r($_POST);
	//print_r($_FILES);
	$folder = $_POST["upload_dir"];
	$folder = filter_var($folder, FILTER_SANITIZE_STRING);
	require_once("classes/uploader.php");
	$num_files = count($_FILES["upload_file"]["name"]);
	$allow_database = false;
	$success_counter = 0;
	$success_files = array();
	if($folder === false )
	{
		echo json_encode(array(false, "Invalid folder"));
		exit(0);
	}
	else if($folder === "dft")
	{
		echo json_encode(array(false, "Please choose a folder"));
		exit(0);
	}
	else if($num_files <=0 )
	{
		echo json_encode(array(false, "You have not uploaded any file"));
		exit(0);
	}
	for($i=0; $i<$num_files; $i++)
	{
		$_file["f_name"] = $_FILES["upload_file"]["name"][$i];
		$_file["f_type"] = $_FILES["upload_file"]["type"][$i];
		$_file["f_size"] = $_FILES["upload_file"]["size"][$i];
		$_file["f_temp"] = $_FILES["upload_file"]["tmp_name"][$i];
		$Uploader = new Uploader($_file);
		$Uploader->_set_upload_dir($home_dir."uploads/");
		$Uploader->_set_url_path($url_path."uploads/");
		$is_valid = $Uploader->check_validity();
		if($is_valid === false)
		{
			$error = "INVALID FILE: ".$Uploader->get_message();
			$Uploader->_unlink_files();
			echo json_encode(array(false, $error));
			exit(0);
		}
		else
		{
			$is_uploaded = $Uploader->upload();
			if($is_uploaded === false)
			{
				$error = "UPLOAD FAILED: ".$Uploader->get_message();
				$Uploader->_unlink_files();
				echo json_encode(array(false, $error));
				exit(0);
			}
			else
			{
				$file_url = $Uploader->get_file_url();
				$dir = $file_url["upload_dir"];
				$success_files[$success_counter] = array(
					"dir"=> $dir, "name"=>$_file["f_name"]);
			}
		}

	}
	if(count($success_files) === $num_files)
	{
		if(isset($_SESSION["success_files"]))
		{
			foreach($success_files as $key=>$val)
				array_push($_SESSION["success_files"], $val);
		}
		else
			$_SESSION["success_files"] = $success_files;
		echo json_encode(array(true, "success", $success_files));
		exit(0);
	}
	else
	{
		$error = "Uncaught error: uploaded ".count($success_files)." 
		while $num_files were expected to be uploaded";
		echo json_encode(array(false, $error));
		exit(0);
	}

}
else
{
	echo "nothing <br>";
	print_r($_POST);
	print_r($_FILES);
}
?>