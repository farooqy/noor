<?php session_start();
//phpinfo();
$home = "http://localhost/sites/alnezam/";
$current_path = getcwd();
$current_dir = "";
echo $current_dir;
system("whoami");
if(isset($_GET['dir']) === false)
{
	$current_dir = "home";
	$dir_id = 0;
}
else if($_GET["dir"] !== "home")
{
	$current_dir = $_GET["dir"];
	$current_dir = filter_var($current_dir, FILTER_SANITIZE_STRING);
	$dir_id = 0;
}
if(isset($_POST["submit"]))
{
	print_r($_POST);
	print_r($_FILES);
}

require_once("classes/account.php");
$Accounts = new Account();
$list_accs = $Accounts->Get_Open_Accounts();
if($list_accs === false)
{
	$account_error = $Accounts->Get_Message();
	unset($list_accs);
}
require_once("classes/inventory.php");
$Inventory = new Inventory();
$list_inv = $Inventory->Get_Open_Inventory();
if($list_inv === false)
{
	unset($list_inv);
	$inventory_error = $Inventory->Get_Message();
}
require_once("classes/folder.php");
$Folder =  new Folder();
$list_folders = $Folder->Get_Dir_Folders($current_dir);
if($list_folders === false)
{
	unset($list_folders);
	$folder_error = $Folder->Get_Message();
}

require_once("classes/ledger.php");
$Ledger = new Ledger();
$Journal = $Ledger->Get_Journal();
if($Journal === false)
{
	unset($Journal);
	$journal_error = $Ledger->Get_Message();
}
else
{
	//var_dump($Journal);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Al Nezam Al Asasy</title>
	<meta charset="utf-8" lang="eng">
	<script type="text/javascript" src="js/jQuery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/menu.css">
	<link rel="stylesheet" type="text/css" href="css/general.css">
	<link rel="stylesheet" type="text/css" href="css/file_container.css">
</head>
<body>
	<div class="container-fluid">
		<div class="row">
		<?php require_once('menu.html');?>
		</div>
		<div class="row">
			<div class="col-md-5 col-lg-5">
			

				<div class="row new_file_container">
					<div class="col-md-12 col-lg-12">
						<form class="file_form row " method="POST" action="" enctype="multipart/form-data">
							<input type="hidden" name="upload_dir" 
							value="<?php echo $current_dir ?>" >
							<div class="upload_trigger mar-t-10" target="upload_file">
								<img src="icons/upload-icon.png" height="60px">
							</div>
							<div class="file_info"></div>
							<input type="file" class="upload_file hide" name="upload_file[]" multiple>
							<input type="reset" class="cancel_upload btn btn-danger" name="reset" value="Reset">
							<input type="submit" class="btn btn-primary" name="submit" value="Save">
							<div class="row mar-t-10">
								<div class="col-md-2 col-lg-2"></div>
								<div class="col-md-8 col-lg-8 loader">
									<div class="row loader-text"></div>
									<div class="row loader-error"></div>
									<div class="row appendfiles"></div>
								</div>
								<div class="col-md-2 col-lg-2"></div>
							</div>
						</form>
					</div>
					<div class="close_pop" target="new_file_container">X</div>
				</div>

				<div class="row new_folder_container <?php 
				if(isset($_GET['display']) && $_GET['display'] === 'folder')
				{
					echo 'current_view display';
				}
				?>">
					<form class="col-md-12 col-lg-12 folder_form" method="POST" action="" 
					enctype="multipart/form-data">
						<div class="row mar-t-10">
							<select name="level">
								<option value="dft">SELECT VISIBILITY</option>
								<option value="all">All</option>
								<option value="admin">Admin Only </option>
							</select>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<input type="text" name="folder_name" placeholder="Enter the folder name" class="folder_name col-md-8 col-lg-8 input-text">
							<input type="hidden" name="parent" 
							value="<?php echo $dir_id?>">
							<input type="hidden" name="parent_di" 
							value="<?php echo $current_dir?>">
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<input type="submit" name="save_folder" value="Save"
							class="btn btn-primary">
							<input type="reset" name="reset" value="Reset" 
							class="btn btn-danger">
						</div>
						<div class="close_pop" target="new_folder_container">
							X
						</div>
					</form>

					<div class="row mar-t-10">
						<div class="col-md-2 col-lg-2"></div>
						<div class="col-md-8 col-lg-8 loader">
							<div class="row loader-text"></div>
							<div class="row loader-error"></div>
							<div class="row appendfiles"></div>
						</div>
						<div class="col-md-2 col-lg-2"></div>
					</div>
				</div>
				<div class="row inventory_container <?php 
				if(isset($_GET['display']) && $_GET['display'] === 'inventory')
					echo 'current_view display';
					?>">
					<form class="col-lg-12 col-md-12 inventory-form" method="POST" action="">
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<div class="col-md-4 col-lg-4">
								<div class="row left-align ul">
									* The inventory serial number 
									will be automatically generated.
								</div>
							</div>
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<input type="text" name="item_name" class="input-text col-md-8 col-lg-8" placeholder="Enter the item name">
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<textarea name="item_desc" class="col-md-8 col-lg-8 non-sizeable" placeholder="Enter the item description" rows="3"></textarea>
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<input type="number" name="item_quantity" class="input-text col-md-8 col-lg-8" placeholder="Enter the item quantity" min="1">
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<input type="number" name="item_price" class="input-text col-md-8 col-lg-8" placeholder="Enter the item price" min="1">
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<input type="submit" name="save_inventory" value="Save"
							class="btn btn-primary">
							<input type="reset" name="reset" value="Reset" 
							class="btn btn-danger">
						</div>
					</form>
					<div class="close_pop" target="inventory_container">
						X
					</div>
					<div class="row mar-t-10">
						<div class="col-md-2 col-lg-2"></div>
						<div class="col-md-8 col-lg-8 loader">
							<div class="row loader-text"></div>
							<div class="row loader-error"></div>
							<div class="row appendfiles"></div>
						</div>
						<div class="col-md-2 col-lg-2"></div>
					</div>
				</div>
				<div class="row account_container 
				<?php
				if(isset($_GET['display']) && $_GET['display'] === 'accounts')
				{
					echo 'current_view display';
				} 
				?> ">
					<form class="col-md-12 col-lg-12 new_acc_form" action="" method="POST">
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<div class="col-md-8 col-lg-8">
								<div class="row left-align ul">
									*Standard account will affect the total asets
								</div>
								<div class="row left-align ul">
									*Extinct account will just show prove of the book keeping and will not feature in the total assets
								</div>
							</div>
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<select name="acc_type" class="col-md-8 col-md-8">
								<option value="dft">Select account type</option>
								<option value="standard">Standard</option>
								<option value="extinct">Extinct</option>
							</select>
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<input type="text" name="acc_name" class="col-lg-8 col-md-8 acc_name input-text" placeholder="Enter the account name">
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<input type="hidden" name="acc_dir" class="col-lg-8 col-md-8 acc_name input-text" placeholder="Enter the account name" 
							value="<?php echo  $dir_id?>">
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<textarea name="acc_desc" class="col-lg-8 col-md-8 acc_desc input-text non-sizeable" placeholder="Enter the account description" rows="3"></textarea>
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<input type="submit" name="submit" value="Save" class="btn btn-primary">
							<input type="reset" name="reset" value="Reset" class="btn btn-danger">
						</div>
					</form>
					<div class="close_pop" target="account_container">
						X
					</div>
					<div class="row mar-t-10">
						<div class="col-md-2 col-lg-2"></div>
						<div class="col-md-8 col-lg-8 loader">
							<div class="row loader-text"></div>
							<div class="row loader-error"></div>
							<div class="row appendfiles"></div>
						</div>
						<div class="col-md-2 col-lg-2"></div>
					</div>
				</div>

				<div class="row daily_cash_container <?php
				if(isset($_GET['display']) && $_GET['display'] === 'dcash')
				{
					echo 'display current_view';
				} 
				?>">
					<form class="col-md-12 col-lg-12 dcash_form" action="" method="POST">
					<?php
					if(isset($account_error))
					{
						?>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<div class="col-md-8 col-lg-8 loader">
								<div class="row loader-text">ERROR</div>
								<div class="row loader-error">
									<?php echo $account_error; ?>
								</div>
								<div class="row appendfiles"></div>
							</div>
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<?php
					} 
					else
					{
						?>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<div class="col-md-8 col-lg-8 left-align">
								From
							</div>
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-5">
							<div class="col-md-2 col-lg-2"></div>
							<select name="cash_effect" class="input-text col-md-8 col-lg-8">
								<option value="dft">Select Account
								</option>
								<?php
								$num_accs = count($list_accs);
								for($i=0; $i<$num_accs; $i++)
								{
									$acc_type = $list_accs[$i]["acc_type"];
									if($acc_type !== "standard")
									{
										continue;
									}
									$acc_name = $list_accs[$i]["acc_name"];
									$acc_id = $list_accs[$i]["acc_id"];

									?>
									<option value="<?php echo $acc_id ;?>">
										<?php echo $acc_name; ?>
									</option>
									<?php
								}
								?>
							</select>
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<div class="col-md-8 col-lg-8 left-align">
								To
							</div>
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-5">
							<div class="col-md-2 col-lg-2"></div>
							<select name="cash_effect_to" class="input-text col-md-8 col-lg-8">
								<option value="dft">Select Account
								</option>
								<?php
								$num_accs = count($list_accs);
								for($i=0; $i<$num_accs; $i++)
								{
									$acc_type = $list_accs[$i]["acc_type"];
									if($acc_type !== "standard")
									{
										continue;
									}
									$acc_name = $list_accs[$i]["acc_name"];
									$acc_id = $list_accs[$i]["acc_id"];

									?>
									<option value="<?php echo $acc_id ;?>">
										<?php echo $acc_name; ?>
									</option>
									<?php
								}
								?>
							</select>
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<textarea name="cash_desc" placeholder="Enter the description" class="non-sizeable col-md-8 col-lg-8" rows='3'></textarea>
							<div class="col-md-2 col-lg-2"></div>
							
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<select name="cash_type" class="non-sizeable col-md-8 col-lg-8 cash_type">
								<option value="dft">Payment type</option>
								<option value="cash">Cash</option>
								<option value="cheque">Cheque</option>
							</select>
							<div class="col-md-2 col-lg-2"></div>
							
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<input name="cheq_num" placeholder="Enter the cheque number" class="input-text col-md-8 col-lg-8 cheq_num" type="number" style="display: none;">
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<input name="trans_amount" placeholder="Enter the amount" class="input-text col-md-8 col-lg-8" type="number" >
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<input type="submit" name="submit" value="Save" class="btn btn-primary">
							<input type="reset" name="reset" value="Reset" class="btn btn-danger">
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<div class="col-md-8 col-lg-8 loader">
								<div class="row loader-text"></div>
								<div class="row loader-error"></div>
								<div class="row appendfiles"></div>
							</div>
							<div class="col-md-2 col-lg-2"></div>
						</div>


						<?php
					}
					?>
						
					</form>
					
				</div>
				<div class="row invoice-container main-bg">
					<form class="col-md-12 col-lg-12" action="" method="POST">
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<div class="col-md-8 col-lg-8">
								*The invoice number will be automaically generated
							</div>
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<input name="invoice_to" placeholder="Enter the receiver" class="input-text col-md-8 col-lg-8" type="number" >
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row">
							<div class="col-md-2 col-lg-2"></div>
							<div class="col-md-8 col-lg-8 loader">
								<div class="row loader-text"></div>
								<div class="row loader-error"></div>
								<div class="row appendfiles"></div>
							</div>
							<div class="col-md-2 col-lg-2"></div>
						</div>
					</form>
				</div>

			</div>
			<div class="col-md-7 col-lg-7">
				<div class="row inventory_container 
				<?php
				if(isset($_GET['display']) && $_GET['display'] === 'inventory')
				{
					echo 'current_view display';
				}
				?> ">
					<div class="col-md-12 col-lg-12 mar-t-5">
						
							<?php
							if(isset($list_inv) && count($list_inv) > 0)
							{
								?>
						<table class="table Inventory-table">
							<thead>
								<tr>
									<th>#</th>
									<th>Serial No</th>
									<th>Item name</th>
									<th>Item desc</th>
									<th>Item quantity</th>
									<th>Item price</th>
									<th>Total Amount</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$num_invs = count($list_inv);
								$total_amount = 0;
								for($inv=0; $inv<$num_invs; $inv++)
								{
									$inv_id =$list_inv[$inv]["item_id"];
									$serial_no = $list_inv[$inv]["serial_no"];
									$name =$list_inv[$inv]["item_name"];
									$desc =$list_inv[$inv]["item_desc"];
									$quan =$list_inv[$inv]["item_quantity"];
									$price=$list_inv[$inv]["item_price"];
									$date =$list_inv[$inv]["item_date"];
									$token =  $list_inv[$inv]["item_token"];
									$amount = $price * $quan;
									$total_amount += $amount;
									$close_link = "inventory?close=1&inv=$inv_id&token=$token";
									?>
								<tr>
									<td><?php echo $inv+1 ?></td>
									<td><?php echo $serial_no ?></td>
									<td><?php echo $name ?></td>
									<td><?php echo $desc ?></td>
									<td><?php echo $quan ?></td>
									<td><?php echo $price ?></td>
									<td><?php echo $amount ?></td>
									<td>
										<a href="<?php echo $close_link ?>" class="btn btn-primary">
											Update
										</a>
									</td>
								</tr>
									<?php
								}
								?>
							</tbody>
						</table>
								<?php
							}
							else if(isset($inventory_error))
							{
								?>
						<div class="row loader-error">
							<?php echo $inventory_error ?>
						</div>
								<?php
							}
							else
							{
								?>
						<div class="row loader-error">
							There are no inventories yet
						</div>
								<?php
							}
							?>
					</div>
				</div>

				<div class="row account_container
				<?php
				if(isset($_GET['display']) && $_GET['display'] === 'accounts')
				{
					echo 'current_view display';
				} ?> ">
					<div class="col-md-12 col-lg-12">
							<?php
							if(isset($list_accs) && count($list_accs) > 0)
							{
								?>
								<table class="table row">
									<thead>
										<tr>
											<th>#</th>
											<th>Name</th>
											<th>Description</th>
											<th>Account type</th>
											<th>View Link</th>
										</tr>
									</thead>
								<?php
								$num_accs = count($list_accs);
								for($i=0; $i<$num_accs; $i++)
								{
									$acc_id = $list_accs[$i]["acc_id"];
									$acc_token = $list_accs[$i]["acc_token"];
									$acc_name = $list_accs[$i]["acc_name"];
									$acc_type = $list_accs[$i]["acc_type"];
									$acc_desc = $list_accs[$i]["acc_desc"];
									$acc_date = $list_accs[$i]["acc_date"];
									$acc_date = gmdate('M-D-Y',$acc_date);
									$acc_status = $list_accs[$i]["acc_status"];
									$acc_dir = $list_accs[$i]["acc_folder"];
									$link = "account=".$acc_id."&token=".$acc_token."&dir=".$acc_dir;
									$acc_link = $home.'accounts?'.$link;
									?>
									<tr>
										<td><?php echo $i+1?></td>
										<td><?php echo $acc_name ?></td>
										<td><?php echo $acc_desc ?></td>
										<td><?php echo $acc_type ?></td>
										<td>
											<a href="<?php echo $acc_link?>" class="btn btn-primary">
												View Account
											</a>
										</td>

									</tr>
									<?php
								}
								?>
								</table>
								<?php
							}
							else if(isset($account_error))
							{
								?>
						<div class="row loader-error">
							<?php echo $account_error ?>
						</div>
								<?php
							}
							else
							{
								?>
						<div class="row loader-error">
							There is no account to display in this folder
						</div>
								<?php
							}
							?>
					</div>
				</div>

				<div class="row new_folder_container left-align <?php
				if(isset($_GET['display']) && $_GET['display'] === 'folder')
				{
					echo 'current_view display';
				} 
				?>">
					<?php
					if(isset($list_folders) && count($list_folders) > 0)
					{
						$num_folds = count($list_folders);
						$icon = $home.'icons/Folder-icon.png';
						$icon_locked = $home.'icons/locked-icon.png';

						for($fold=0; $fold<$num_folds; $fold++)
						{
							$f_id = $list_folders[$fold]["folder_id"];
							$f_name = $list_folders[$fold]["folder_name"];
							$icon_url = $home.'?dir=$f_name';
							$is_visible =  $list_folders[$fold]["folder_visible"];
							if(isset($_SESSION["boss"]))
							{
								?>
								<div class="icon">
									<a href="<?php echo $icon_url ?>">
										<img src="<?php echo $icon ?>" class="folder-icon">
										<div>
											<?php echo $f_name ?>
										</div>
									</a>
										
								</div>
								<?php
							}
							else if($is_visible === 'all')
							{
								?>
								<div class="icon">
									<a href="<?php echo $icon_url ?>">
										<img src="<?php echo $icon ?>" class="folder-icon">
										<div>
											<?php echo $f_name ?>
										</div>
									</a>
								</div>
								<?php
							}
							else
							{
								?>
								<div class="icon locked-icon">
									<img src="<?php echo $icon_locked?>" class="folder-icon">
									<div>
										<?php echo $f_name ?>
									</div>
								</div>
								<?php
							}
						}
					} 
					?>	
				</div>

				<div class="row daily_cash_container <?php
				if(isset($_GET['display']) && $_GET['display'] === 'dcash')
				{
					echo 'current_view display';
				} 
				?>">
				<div class="col-md-12 col-lg-12">
					<?php
					if(isset($journal_error))
					{
						?>
						<div class="row err-div mar-t-10" style="display: block;">
							<?php echo $journal_error ?>
						</div>
						<?php
					}
					else if(is_array($Journal) === false)
					{
						print_r($Journal);
						?>
						<div class="row err-div mar-t-10 display" >

							<?php echo "Non array data";
							var_dump($Journal)?>
						</div>
						<?php
					}
					else if(count($Journal) === 0)
					{
						?>
						<div class="row err-div mar-t-10 display" >
							<?php echo "The journal is empty"?>
						</div>
						<?php
					}
					else
					{
						?>
						<table class="table mar-t-10 journal-table">
							<thead>
								<th>#</th>
								<th>Date</th>
								<th>Account</th>
								<th>Description</th>
								<th>Mehod</th>
								<th>Cheque #</th>
								<th>Debit</th>
								<th>Credit</th>
							</thead>
							<tbody>
								<?php
								$num_js = count($Journal);
								$balance = 0;
								for($i=0; $i<$num_js; $i++)
								{
									$date = $Journal[$i]["cash_date"];
									$date = gmdate('D- M-d-Y',$date);
									$acc_credit =$Journal[$i]["cash_trans_from"];
									$acc_debit = $Journal[$i]["cash_trans_to"];
									$acc_desc = $Journal[$i]["cash_desc"];
									$cash_amount = $Journal[$i]["cash_amount"];
									$method = $Journal[$i]["cash_type"];
									$cheq_no = $Journal[$i]["cash_cheq_no"];

									$debit_det = $Accounts->Get_Account_Detail($acc_debit);
									$debit_token = '';
									$credit_token = '';
									$debit_dir = '';
									$credit_dir ='';
									if($debit_det === false)
									{
										$debit_name = "Error";
									}
									else if(count($debit_det) <= 0)
									{
										$debit_name = "No account";
									}
									else
									{
										$debit_name = $debit_det[0]["acc_name"];
										$debit_token = $debit_det[0]["acc_token"];
										$debit_dir = $debit_det[0]["acc_folder"];
									}
									$credit_det = $Accounts->Get_Account_Detail($acc_credit);
									if($credit_det === false)
									{
										$credit_name = "Error";
									}
									else if(count($credit_det) <= 0)
									{
										$credit_name = "No account";
									}
									else
									{
										$credit_name = $credit_det[0]["acc_name"];
										$credit_token = $credit_det[0]["acc_token"];
										$credit_dir = $credit_det[0]["acc_folder"];
									}
									$debit_link = $home.'accounts?account='.$acc_debit.'&token='.$debit_token.'&dir='.$debit_dir;
									$credit_link = $home.'accounts?account='.$acc_credit.'&token='.$credit_token.'&dir='.$credit_dir;
									?>
									<tr class="debit-row">
										<td><?php echo $i+1 ?></td>
										<td><?php echo $date ?></td>
										<td>
										<a href="<?php echo $debit_link ?>" class="black">
											<?php echo $debit_name?>
										</a>
										</td>
										<td><?php echo $acc_desc?></td>
										<td><?php echo $method ?></td>
										<td><?php echo $cheq_no ?></td>
										<td><?php echo $cash_amount ?></td>
										<td><?php echo "0" ?></td>
									</tr>
									<tr class="credit_row">
										<td><?php ?></td>
										<td><?php echo "-- -- --" ?></td>
										<td>
											<a href="<?php echo $credit_link ?>" class="white">
												<?php echo $credit_name?>
											</a>
										</td>
										<td><?php echo $method ?></td>
										<td><?php echo $cheq_no ?></td>
										<td><?php echo "-- -- --"?></td>
										<td><?php echo "0" ?></td>
										<td><?php echo $cash_amount ?></td>
									</tr>
									<?php
								} 
								?>
							</tbody>
						</table>
						<?php
					}
					?>
				</div>
				</div>

			</div>
		</div>
	</div>
</body>
</html>