<?php 

require_once("classes/inventory.php");
if(isset($_POST["item_name"]) && isset($_POST["item_price"]))
{
	$item_name = $_POST["item_name"];
	$item_name = filter_var($item_name, FILTER_SANITIZE_STRING);
	$item_desc = $_POST["item_desc"];
	$item_desc = filter_var($item_desc, FILTER_SANITIZE_STRING);
	$item_quan = $_POST["item_quantity"];
	$item_quan = filter_var($item_quan, FILTER_VALIDATE_INT);
	$item_price = $_POST["item_price"];
	$item_price = filter_var($item_price, FILTER_VALIDATE_INT);

	$details = array(
		"item_name" => $item_name,
		"item_desc" => $item_desc,
		"item_quan" => $item_quan,
		"item_price" => $item_price
		);
	foreach($details as $key=> $item)
	{
		if($key === "item_quan" || $key === "item_price")
			continue;
		if(empty($item))
		{
			echo json_encode(array(false,"The item $key has to be filled "));
			exit(0);
		}
	}
	if($item_price === false || $item_price < 0)
	{
		$error = "The item price should not be a string or less 0 price unit";
		echo json_encode(array(false, $error));
		exit(0);
	}
	else if(!$item_quan || $item_quan < 1)
	{
		$error = "The item quantity should be a a string or less than 1 quantity unit";
		echo json_encode(array(false, $error));
		exit(0);
	}
	else
	{
		$Inventory_Handle = new Inventory();
		$is_set = $Inventory_Handle->Set_Details($details);
		if($is_set === false)
		{
			$error = $Inventory_Handle->Get_Message();
			echo json_encode(array(false, $error));
			exit(0);
		}
		$is_saved = $Inventory_Handle->Save_Inventory();
		if($is_saved)
		{
			echo json_encode(array(true, "success"));
			exit(0);
		}
		else
		{
			$error = $Inventory_Handle->Get_Message();
			echo json_encode(array(false, $error));
			exit(0);
		}
	}



}
else
{
	echo json_encode(array(false, "You cannot pet a monster unless 
		you know how to feed it well"));
}
?>