<?php session_start();

if(isset($_POST["acc_type"]) && isset($_POST["acc_name"]))
{
	//print_r($_POST);
	//exit(0);
	$acc_type = $_POST["acc_type"];
	$acc_type = filter_var($acc_type, FILTER_SANITIZE_STRING);
	$acc_name = $_POST["acc_name"];
	$acc_name = filter_var($acc_name, FILTER_SANITIZE_STRING);
	$acc_desc = (isset($_POST["acc_desc"])?$_POST["acc_desc"]:"");
	$acc_desc = filter_var($acc_desc, FILTER_SANITIZE_STRING);
	$acc_dir = $_POST["acc_dir"];
	$acc_dir = filter_var($acc_dir, FILTER_VALIDATE_INT);
	$type_formats = array("standard", "extinct");

	$details = array(
		"acc_name" => $acc_name,
		"acc_type" => $acc_type,
		"acc_desc" => $acc_desc
		);
	$names = array(
		"acc_desc" => "Account description",
		"acc_type" => "Account type",
		"acc_name" => "Account name"
		);
	if(in_array($acc_type, $type_formats) === false)
	{
		echo json_encode(array(
			false,
			"The type of the account is not recognized"
			));
		exit(0);
	}
	else if($acc_dir === false)
	{
		echo json_encode(array(
			false,
			'The account directory is not valid'
			));
		exit(0);
	}
	else if($acc_dir !== 0)
	{
		require_once("classes/folder.php");
		$Folder = new Folder();
		$dir_info = $Folder->Get_Given_Folder($acc_dir);
		if($dir_info === false )
		{
			echo json_encode(array(
				false,
				'Failed in verifying folder '.$Folder->Get_Message()
				));
			exit(0);
		}
		else if(is_array($dir_info) === false)
		{
			echo json_encode(array(
				false,
				'Returned non array data for verifying the folder'
				));
			exit(0);
		}
		else if(count($dir_info) <= 0)
		{
			echo json_encode(array(
				false,
				'The directory you are using is deleted or does not exist'
				));
			exit(0);
		}
		else if(count($dir_info) > 1)
		{
			echo json_encode(array(
				false,
				'The directory you are using has a collision, please contact the admin to solve the problem'
				));
			exit(0);
		}
		else
		{
			//all cool
		}
			
	}
	foreach ($details as $key => $value) {
		if(empty($value)|| $value === "dft")
		{
			$field = $names[$key];
			echo json_encode(array(false, 
				"The field $field should not be empty"));
			exit(0);
		}
	}
	//echo json_encode(array(true,"Ready for theDB"));
	require_once("classes/account.php");
	$Account = new Account();
	$details["acc_dir"] = $acc_dir;
	$Account->Set_Acc_Details($details);
	$is_saved = $Account->Save_Account();
	if($is_saved === true)
	{
		echo json_encode(array(true, "success"));
		exit(0);
	}
	else 
	{
		$error = $Account->Get_Message();
		echo json_encode(array(false, $error));
		exit(0);
	}
}
else 
{
	echo json_encode(array(false,"You can't pet a lion and expect 
		it not to eat your ass if you don't feed it"));
	exit(0);
}
?>