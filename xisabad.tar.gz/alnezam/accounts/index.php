<?php session_start();
//phpinfo();
$home = "http://localhost/sites/alnezam/";

require_once("../classes/account.php");
$Accounts = new Account();
if(isset($_GET["account"]) && isset($_GET["token"]) && isset($_GET["dir"]))
{
	$account = $_GET["account"];
	$account = filter_var($account, FILTER_VALIDATE_INT);
	$token = $_GET["token"];
	$token = filter_var($token, FILTER_SANITIZE_STRING);
	$dir = $_GET["dir"];
	$dir = filter_var($dir, FILTER_VALIDATE_INT);

	if($account === false)
	{
		$error_trigger = "The inavlid account parameter";
	}
	else if($dir === false)
	{
		$error_trigger = "Invalid parameter passed as the 2nd argument";
	}
	else 
	{
		//verify;
		$acc_details = $Accounts->Get_Account($token, $account);
		if($acc_details === false)
		{
			$error = $Accounts->Get_Message();
			$error_trigger = "Failed to verify account: ".$error;
		}
		else if(count($acc_details) <= 0)
		{
			$error_trigger = "The account you are looking doest not 
			exist";
		}
		else if(is_array($acc_details) === false)
		{
			$error_trigger = "The account has returned unknown data please contact the admininstrator";
		}
		else if(count($acc_details) > 1)
		{
			$error_trigger = "The account has a collision, please contact the admin to solve the problem";
		}
		else
		{
			$acc_type = $acc_details[0]["acc_type"];
			$hash_type = hash('md5', $acc_type, false);
			$acc_status = $acc_details[0]["acc_status"];
			$hash_status = hash('md5', $acc_status, false);
			$acc_name = $acc_details[0]["acc_name"];
			$hash_name = hash('md5', $acc_name, false);
			$acc_desc = $acc_details[0]["acc_desc"];
			$hash_desc= hash('md5', $acc_desc, false);
			$acc_trans = $Accounts->Get_Ledger($account);
			if($acc_trans === false)
			{
				$error = $Accounts->Get_Message();
				$error_trigger = "Failed to get the ledger: ".$error;
			}
			else if(is_array($acc_trans) === false)
			{
				$error_trigger = "The ledger data type is uknown";
			}
			else if(count($acc_trans) <=0 )
			{
				$empty_ledger = true;
			}
			else
			{
				//all good;
			}

		}
	}
}
else
{
	header("Location: $home");
	exit(0);
}
$jquery = $home.'js/jQuery.js';
$btstrap = $home.'js/bootstrap.js';
$main = $home.'js/main.js';
$btmin = $home.'css/bootstrap.min.css';
$menu = $home.'css/menu.css';
$general = $home.'css/general.css';
$fcont = $home.'css/file_container.css';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Al Nezam Al Asasy</title>
	<meta charset="utf-8" lang="eng">
	<script type="text/javascript" src="<?php echo $jquery ?>"></script>
	<script type="text/javascript" src="<?php echo $btstrap ?>"></script>
	<script type="text/javascript" src="<?php echo $main?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo $btmin?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $menu ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $general ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo $fcont ?>">
</head>
<body>
	<div class="container-fluid">
		<div class="row">
		<?php require_once('../menu.html');?>
		</div>
		<div class="row">
			<div class="col-md-5 col-lg-5 container-acc display">
			<?php
			if(isset($error_trigger))
			{
				?>
				<div class="row load-error">
					<?php
					echo $error_trigger; 
					?>
				</div>
				<?php
			}
			else
			{
				?>
				<form class="row" action="" method="POST" >
					<div class="col-md-12 col-lg-12">
					<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<input type="text" name="acc_name" 
							value="<?php echo $acc_name ?>" disabled 
							class="input col-md-8 col-lg-8">
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<textarea type="text" name="acc_desc" disabled class="input col-md-8 col-lg-8 non-sizeable" rows='3'><?php echo $acc_desc ?></textarea>
							<div class="col-md-2 col-lg-2"></div>
						</div>
					<?php 
					if($acc_type === "standard")
					{
						?>
						<div class="row align-left black mar-t-30">
						!! You cannot edit this account. Please refer to the daily cash if this account is not correct.
						</div>
						<?php
					}
					else
					{
						?>
						<div class="row align-left black mar-t-30">
						This account is extinct, any changes you make to this account does not affect other ledgers
						</div>
						<div class="row mar-t-10">
							<div class="col-md-2 col-lg-2"></div>
							<select class="col-md-3 col-lg-3" name='trans_type'>
								<option value="dft">Select type</option>
								<option value="Debit">Debit</option>
								<option value="Credit">Credit</option>
							</select>
							<input type="number" name="acc_trans" 
							value="" min='1' placeholder="Debit or credit account" 
							class="input col-md-5 col-lg-5">
							<div class="col-md-2 col-lg-2"></div>
						</div>
						<?php
					}
					?>
				
						
						
					</div>
				</form>
				<?php
			}
			?>
			</div>
			<div class="col-lg-7 col-md-7 main-bg display">
			<?php
			if(isset($empty_ledger))
			{
				?>
				<div class="row err-div">
					The account does not have any transactions yet
				</div>
				<?php
			}
			else
			{
				?>
				<div class="row mar-t-10 white bold ul font-20">
					<?php echo $acc_details[0]["acc_name"] ?>
				</div>
				<table class="table row">
					<thead>
						<th>#</th>
						<th>Date</th>
						<th>Description</th>
						<th>Method</th>
						<th>Cheque #</th>
						<th>Debit</th>
						<th>Credit</th>
						<th>Balance</th>
					</thead>
					<tbody>
						<?php
						$num_trans = count($acc_trans);
						$Balance = 0;
						for($i=0; $i<$num_trans; $i++)
						{
							$date = $acc_trans[$i]["cash_date"];
							$date = gmdate('D-M-d-Y',$date);
							$desc = $acc_trans[$i]["cash_desc"];
							$type = $acc_trans[$i]["cash_type"];
							$cheq = $acc_trans[$i]["cash_cheq_no"];
							$amount = $acc_trans[$i]["cash_amount"];
							$debit = $acc_trans[$i]["cash_trans_to"];
							$credit = $acc_trans[$i]["cash_trans_from"];
							$amount_debit = 0;
							$amount_credit = 0;
							if($debit === $acc_details[0]["acc_id"])
							{
								$Balance +=$amount;
								$amount_debit = $amount;
								$amount_credit = 0;
							}
							else if($credit === $acc_details[0]["acc_id"])
							{
								$Balance -= $amount;
								$amount_credit = $amount;
								$amount_debit = 0;
							}
							else
							{
								//$amount_credit = 999;
								$amount_debit = 0; 
								$amount_credit = 0;
							}
							?>
							<tr>
								<td><?php echo $i+1 ?></td>
								<td><?php echo $date ?></td>
								<td><?php echo $desc ?></td>
								<td><?php echo $type ?></td>
								<td><?php echo $cheq ?></td>
								<td><?php echo $amount_debit ?></td>
								<td><?php echo $amount_credit ?></td>
								<td><?php echo $Balance ?></td>
							</tr>
							<?php
						}
						//print_r($acc_trans);
						?>
					</tbody>
				</table>
				<div class="row info-div">
					<?php 
					if($Balance > 0)
					{
						echo 'This account is an asset of '.$Balance;
					}
					else
						echo 'This account is a liability of '.$Balance;
					?>
				</div>
				<?php
			}
			?>
			</div>
		</div>
	</div>
</body>
</html>